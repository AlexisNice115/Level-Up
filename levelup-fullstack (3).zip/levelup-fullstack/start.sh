#!/bin/bash

# LevelUp Fullstack Startup Script
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║           LevelUp - Full Stack Game Recommender           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# Check for MongoDB
echo "Checking MongoDB..."
if command -v mongod &> /dev/null; then
    echo "✓ MongoDB found"
else
    echo "✗ MongoDB not found. Please install it first."
    echo "  macOS: brew install mongodb-community"
    exit 1
fi

# Check for Java
echo "Checking Java..."
if command -v java &> /dev/null; then
    echo "✓ Java found: $(java -version 2>&1 | head -n 1)"
else
    echo "✗ Java not found. Please install JDK 17+"
    exit 1
fi

# Check for Maven
echo "Checking Maven..."
if command -v mvn &> /dev/null; then
    echo "✓ Maven found"
else
    echo "✗ Maven not found. Please install Maven 3.6+"
    exit 1
fi

# Check for Node.js
echo "Checking Node.js..."
if command -v node &> /dev/null; then
    echo "✓ Node.js found: $(node -v)"
else
    echo "✗ Node.js not found. Please install Node.js 18+"
    exit 1
fi

echo ""
echo "All dependencies found!"
echo ""

# Function to cleanup on exit
cleanup() {
    echo ""
    echo "Shutting down..."
    kill $BACKEND_PID 2>/dev/null
    kill $FRONTEND_PID 2>/dev/null
    exit 0
}

trap cleanup SIGINT SIGTERM

# Start Backend
echo "Starting Backend (Spring Boot)..."
cd backend
mvn spring-boot:run &
BACKEND_PID=$!
cd ..

# Wait for backend to start
echo "Waiting for backend to initialize..."
sleep 15

# Start Frontend
echo "Starting Frontend (React)..."
cd frontend
npm install
npm run dev &
FRONTEND_PID=$!
cd ..

echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                    SERVERS STARTED                        ║"
echo "╠═══════════════════════════════════════════════════════════╣"
echo "║  Frontend: http://localhost:3000                          ║"
echo "║  Backend:  http://localhost:8080                          ║"
echo "║                                                           ║"
echo "║  Press Ctrl+C to stop both servers                        ║"
echo "╚═══════════════════════════════════════════════════════════╝"

# Wait for processes
wait
