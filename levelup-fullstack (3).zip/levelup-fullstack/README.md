# LevelUp - Full Stack Game Recommender

A complete game recommendation system with React frontend and Spring Boot backend.

## 📁 Project Structure

```
levelup-fullstack/
├── frontend/          # React + Vite frontend
│   ├── src/
│   │   ├── App.jsx    # Main React component
│   │   ├── main.jsx   # Entry point
│   │   └── index.css  # Tailwind CSS
│   ├── package.json
│   └── vite.config.js
│
├── backend/           # Spring Boot REST API
│   ├── src/main/java/com/gamerecommender/
│   │   ├── GameRecommenderApplication.java
│   │   ├── controller/GameController.java
│   │   ├── service/GameService.java
│   │   ├── repository/GameRepository.java
│   │   ├── entity/Game.java
│   │   └── config/
│   │       ├── CorsConfig.java
│   │       └── DataLoader.java
│   └── pom.xml
│
└── README.md
```

## 🚀 Quick Start

### Prerequisites

- **Java 17+** (for backend)
- **Maven 3.6+** (for backend)
- **Node.js 18+** (for frontend)
- **MongoDB** (database)

### Step 1: Start MongoDB

**macOS:**
```bash
brew services start mongodb-community
```

**Linux:**
```bash
sudo systemctl start mongod
```

**Windows:**
```bash
net start MongoDB
```

### Step 2: Start the Backend (Terminal 1)

```bash
cd levelup-fullstack/backend
mvn spring-boot:run
```

You should see:
```
Started GameRecommenderApplication
Loading game database...
Loaded 119 games!
```

Backend runs on: **http://localhost:8080**

### Step 3: Start the Frontend (Terminal 2)

```bash
cd levelup-fullstack/frontend
npm install
npm run dev
```

You should see:
```
VITE ready in XXX ms
➜ Local: http://localhost:3000/
```

Frontend runs on: **http://localhost:3000**

### Step 4: Open the App

Go to **http://localhost:3000** in your browser!

---

## 🔌 How They Connect

```
┌─────────────────┐       HTTP        ┌─────────────────┐       MongoDB      ┌─────────────────┐
│                 │   GET /api/games  │                 │    Driver          │                 │
│  React Frontend │ ───────────────►  │  Spring Boot    │ ──────────────►    │    MongoDB      │
│  (Port 3000)    │ ◄───────────────  │  (Port 8080)    │ ◄──────────────    │  (Port 27017)   │
│                 │    JSON Response  │                 │    Documents       │                 │
└─────────────────┘                   └─────────────────┘                    └─────────────────┘
```

### API Endpoints Used by Frontend

| Frontend Action | API Call |
|-----------------|----------|
| Load all games | `GET /api/games` |
| Search games | `GET /api/games/search?q=zelda` |
| Get similar games | `GET /api/games/recommend/12` |
| Get by preferences | `GET /api/games/recommend?genres=RPG&minRating=80` |

---

## 🎮 Features

### Frontend (React)
- ✅ Browse 119 games from database
- ✅ Search games in real-time
- ✅ Filter by genre and platform
- ✅ Get AI recommendations based on viewed games
- ✅ Save favorites (per session)
- ✅ View history
- ✅ Connection status indicator
- ✅ Guest/Login modes

### Backend (Spring Boot)
- ✅ REST API with full CRUD
- ✅ MongoDB integration
- ✅ Auto-loads 119 games on startup
- ✅ Search across title and genres
- ✅ Recommendation engine
- ✅ CORS enabled for frontend

---

## 📝 API Documentation

### Get All Games
```bash
curl http://localhost:8080/api/games
```

### Search Games
```bash
curl "http://localhost:8080/api/games/search?q=zelda"
```

### Get Recommendations for a Game
```bash
curl http://localhost:8080/api/games/recommend/12
```

### Get Recommendations by Preferences
```bash
curl "http://localhost:8080/api/games/recommend?genres=RPG,Action&minRating=85&limit=5"
```

### Add a New Game
```bash
curl -X POST http://localhost:8080/api/games \
  -H "Content-Type: application/json" \
  -d '{
    "title": "New Game",
    "year": 2024,
    "primaryGenre": "RPG",
    "secondaryGenres": "Action",
    "thirdGenre": "Fantasy",
    "rating": 90,
    "platforms": "Steam"
  }'
```

---

## 🛠️ Development

### Frontend Development
```bash
cd frontend
npm run dev      # Start dev server with hot reload
npm run build    # Build for production
npm run preview  # Preview production build
```

### Backend Development
```bash
cd backend
mvn spring-boot:run                    # Run with hot reload
mvn clean package                      # Build JAR
java -jar target/game-recommender-api-1.0.0.jar  # Run JAR
```

### View MongoDB Data
```bash
mongosh
use gameRecommender
db.games.find().pretty()
db.games.countDocuments()
```

---

## 🔧 Configuration

### Frontend - Change API URL
Edit `frontend/src/App.jsx`:
```javascript
const API_URL = 'http://localhost:8080/api/games';
```

### Backend - Change Port
Edit `backend/src/main/resources/application.properties`:
```properties
server.port=8080
spring.data.mongodb.uri=mongodb://localhost:27017/gameRecommender
```

---

## 🐛 Troubleshooting

### "Cannot connect to backend"
1. Make sure MongoDB is running
2. Make sure backend is running on port 8080
3. Check browser console for CORS errors

### "No games loaded"
1. Check MongoDB connection
2. Look at backend console for errors
3. Try: `curl http://localhost:8080/api/games/count`

### Frontend won't start
```bash
cd frontend
rm -rf node_modules
npm install
npm run dev
```

### Backend won't start
```bash
cd backend
mvn clean install
mvn spring-boot:run
```

---

## 📦 Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18, Vite, Tailwind CSS |
| Backend | Spring Boot 3.2, Java 17 |
| Database | MongoDB |
| API | REST (JSON) |
| Icons | Lucide React |

---

## 👥 Team

CSCI 318 Project - LevelUp Game Recommender
