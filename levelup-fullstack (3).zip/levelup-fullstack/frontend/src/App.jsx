import React, { useState, useEffect } from 'react';
import { 
  Search, Gamepad2, Star, User, LogOut, Sparkles, X, Menu,
  TrendingUp, History, RefreshCw, Database, Wifi, WifiOff,
  Filter, Tag, Type, Sliders, MessageSquare, Library, Home,
  ChevronRight, ChevronLeft, Check, Percent, ThumbsUp, Zap,
  Users, BookOpen, Target, Heart, Settings, Save, Trash2,
  UserCircle, Mail, Lock, Edit, Crown, Award, Bookmark
} from 'lucide-react';

// API Base URL
const API_URL = 'http://localhost:8080/api/games';

// Local Storage Keys
const STORAGE_KEYS = {
  PROFILES: 'levelup_profiles',
  CURRENT_USER: 'levelup_current_user'
};

function App() {
  // Connection State
  const [isConnected, setIsConnected] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Games from Backend
  const [games, setGames] = useState([]);
  const [genres, setGenres] = useState([]);
  const [filteredGames, setFilteredGames] = useState([]);

  // User State
  const [user, setUser] = useState(null);
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState('signin');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authUsername, setAuthUsername] = useState('');

  // Navigation
  const [currentPage, setCurrentPage] = useState('landing');
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  // User Data (persisted in profile)
  const [favorites, setFavorites] = useState([]);
  const [playHistory, setPlayHistory] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [favoriteBasedRecs, setFavoriteBasedRecs] = useState([]);

  // Search/Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('');
  const [selectedTag, setSelectedTag] = useState('');
  const [describeText, setDescribeText] = useState('');
  
  // Advanced Filter States
  const [advancedFilters, setAdvancedFilters] = useState({
    genre: '',
    platform: '',
    minRating: 0,
    maxYear: 2025,
    minYear: 2000
  });

  // Recommendation Setup State
  const [recSetup, setRecSetup] = useState({
    step: 1,
    genres: [],
    platform: '',
    multiplayer: '',
    storyImportance: '',
    difficulty: '',
    mood: '',
    completed: false
  });
  const [recResults, setRecResults] = useState([]);

  // Profile Edit State
  const [editingProfile, setEditingProfile] = useState(false);
  const [profileForm, setProfileForm] = useState({ username: '', email: '' });

  // Available tags
  const [tags, setTags] = useState([]);
  const platforms = ['Steam', 'PlayStation Store', 'Epic Games Store', 'Xbox Game Pass', 'Nintendo Switch', 'Google Play / App Store', 'Battle.net', 'GOG'];

  // ==================== LOCAL STORAGE / PROFILE SYSTEM ====================

  // Load profiles from localStorage
  const loadProfiles = () => {
    try {
      const profiles = localStorage.getItem(STORAGE_KEYS.PROFILES);
      return profiles ? JSON.parse(profiles) : {};
    } catch {
      return {};
    }
  };

  // Save profiles to localStorage
  const saveProfiles = (profiles) => {
    localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(profiles));
  };

  // Get current user's profile
  const getUserProfile = (email) => {
    const profiles = loadProfiles();
    return profiles[email] || null;
  };

  // Save user profile
  const saveUserProfile = (email, profileData) => {
    const profiles = loadProfiles();
    profiles[email] = {
      ...profiles[email],
      ...profileData,
      lastUpdated: new Date().toISOString()
    };
    saveProfiles(profiles);
  };

  // Load user session on mount
  useEffect(() => {
    const savedUser = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser);
        setUser(userData);
        loadUserData(userData.email);
        setCurrentPage('home');
      } catch {
        localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
      }
    }
  }, []);

  // Load user's saved data
  const loadUserData = (email) => {
    if (!email || email === 'guest@levelup.com') return;
    
    const profile = getUserProfile(email);
    if (profile) {
      setFavorites(profile.favorites || []);
      setPlayHistory(profile.playHistory || []);
    }
  };

  // Save user data whenever favorites or history changes
  useEffect(() => {
    if (user && !user.isGuest && user.email) {
      saveUserProfile(user.email, {
        username: user.username,
        email: user.email,
        favorites: favorites,
        playHistory: playHistory
      });
    }
  }, [favorites, playHistory, user]);

  // ==================== API CALLS ====================

  const fetchGames = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(API_URL);
      if (!response.ok) throw new Error('Failed to fetch games');
      const data = await response.json();
      setGames(data);
      setFilteredGames(data);
      setIsConnected(true);
      
      const uniqueGenres = [...new Set(data.map(g => g.primaryGenre).filter(Boolean))].sort();
      setGenres(uniqueGenres);
      
      const allTags = new Set();
      data.forEach(g => {
        if (g.secondaryGenres) allTags.add(g.secondaryGenres);
        if (g.thirdGenre) allTags.add(g.thirdGenre);
      });
      setTags([...allTags].sort());
    } catch (err) {
      setError('Cannot connect to backend. Make sure the API is running on localhost:8080');
      setIsConnected(false);
    } finally {
      setIsLoading(false);
    }
  };

  const searchByTitle = async (query) => {
    if (!query.trim()) {
      setFilteredGames(games);
      return;
    }
    try {
      const response = await fetch(`${API_URL}/search?q=${encodeURIComponent(query)}`);
      const data = await response.json();
      setFilteredGames(data);
    } catch (err) {
      console.error('Search error:', err);
    }
  };

  const searchByGenre = async (genre) => {
    if (!genre) {
      setFilteredGames(games);
      return;
    }
    try {
      const response = await fetch(`${API_URL}/genre/${encodeURIComponent(genre)}`);
      const data = await response.json();
      setFilteredGames(data);
    } catch (err) {
      console.error('Genre search error:', err);
    }
  };

  useEffect(() => {
    fetchGames();
  }, []);

  // ==================== FAVORITES SYSTEM ====================

  const toggleFavorite = (game) => {
    setFavorites(prev => {
      const exists = prev.find(g => g.gameId === game.gameId);
      if (exists) {
        return prev.filter(g => g.gameId !== game.gameId);
      }
      return [...prev, { ...game, favoritedAt: new Date().toISOString() }];
    });
  };

  const isFavorite = (gameId) => {
    return favorites.some(g => g.gameId === gameId);
  };

  const clearAllFavorites = () => {
    if (confirm('Are you sure you want to remove all favorites?')) {
      setFavorites([]);
    }
  };

  // ==================== FAVORITE-BASED RECOMMENDATIONS ====================

  const generateFavoriteBasedRecs = () => {
    if (favorites.length === 0) {
      setFavoriteBasedRecs([]);
      return;
    }

    // Analyze favorite games
    const favoriteGenres = {};
    const favoriteTags = {};
    const favoritePlatforms = {};
    let avgRating = 0;

    favorites.forEach(fav => {
      // Count genres
      if (fav.primaryGenre) {
        favoriteGenres[fav.primaryGenre] = (favoriteGenres[fav.primaryGenre] || 0) + 3;
      }
      if (fav.secondaryGenres) {
        favoriteGenres[fav.secondaryGenres] = (favoriteGenres[fav.secondaryGenres] || 0) + 2;
      }
      if (fav.thirdGenre) {
        favoriteTags[fav.thirdGenre] = (favoriteTags[fav.thirdGenre] || 0) + 1;
      }
      
      // Count platforms
      if (fav.platforms) {
        fav.platforms.split(' / ').forEach(p => {
          favoritePlatforms[p.trim()] = (favoritePlatforms[p.trim()] || 0) + 1;
        });
      }

      avgRating += fav.rating || 0;
    });

    avgRating = avgRating / favorites.length;

    // Score all games
    const scoredGames = games
      .filter(game => !favorites.find(f => f.gameId === game.gameId)) // Exclude already favorited
      .map(game => {
        let score = 0;
        let reasons = [];

        // Genre matching
        if (favoriteGenres[game.primaryGenre]) {
          score += favoriteGenres[game.primaryGenre] * 10;
          reasons.push(`You like ${game.primaryGenre} games`);
        }
        if (favoriteGenres[game.secondaryGenres]) {
          score += favoriteGenres[game.secondaryGenres] * 5;
        }
        
        // Tag matching
        if (favoriteTags[game.thirdGenre]) {
          score += favoriteTags[game.thirdGenre] * 5;
          reasons.push(`Similar style to your favorites`);
        }

        // Rating similarity bonus
        if (game.rating >= avgRating - 10) {
          score += 10;
          if (game.rating >= 85) {
            reasons.push(`Highly rated (${game.rating}%)`);
          }
        }

        // Same developer style (based on genre combinations)
        favorites.forEach(fav => {
          if (fav.primaryGenre === game.primaryGenre && fav.secondaryGenres === game.secondaryGenres) {
            score += 15;
            reasons.push(`Very similar to ${fav.title}`);
          }
        });

        const matchPercentage = Math.min(99, Math.round((score / 80) * 100));

        return {
          ...game,
          matchPercentage,
          reasons: [...new Set(reasons)].slice(0, 3)
        };
      })
      .filter(g => g.matchPercentage > 30)
      .sort((a, b) => b.matchPercentage - a.matchPercentage)
      .slice(0, 10);

    setFavoriteBasedRecs(scoredGames);
  };

  // Generate recommendations when favorites change
  useEffect(() => {
    if (games.length > 0 && favorites.length > 0) {
      generateFavoriteBasedRecs();
    }
  }, [favorites, games]);

  // ==================== HISTORY ====================

  const addToHistory = (game) => {
    setPlayHistory(prev => {
      const filtered = prev.filter(g => g.gameId !== game.gameId);
      return [{ ...game, viewedAt: new Date().toISOString() }, ...filtered].slice(0, 20);
    });
  };

  // ==================== RECOMMENDATION CALCULATOR ====================

  const calculateRecommendations = () => {
    const { genres: selectedGenres, platform, multiplayer, storyImportance, difficulty, mood } = recSetup;
    
    const scoredGames = games.map(game => {
      let score = 0;
      let maxScore = 0;
      let reasons = [];

      // Genre matching (40 points max)
      maxScore += 40;
      if (selectedGenres.length > 0) {
        const genreMatch = selectedGenres.some(g => 
          game.primaryGenre?.toLowerCase().includes(g.toLowerCase()) ||
          game.secondaryGenres?.toLowerCase().includes(g.toLowerCase()) ||
          game.thirdGenre?.toLowerCase().includes(g.toLowerCase())
        );
        if (genreMatch) {
          score += 40;
          reasons.push(`Matches your preferred genre`);
        }
      } else {
        score += 20;
      }

      // Platform matching (15 points)
      maxScore += 15;
      if (platform) {
        if (game.platforms?.includes(platform)) {
          score += 15;
          reasons.push(`Available on ${platform}`);
        }
      } else {
        score += 7;
      }

      // Multiplayer preference (15 points)
      maxScore += 15;
      const gameHasMultiplayer = 
        game.secondaryGenres?.toLowerCase().includes('multiplayer') ||
        game.secondaryGenres?.toLowerCase().includes('co-op') ||
        game.thirdGenre?.toLowerCase().includes('multiplayer') ||
        game.thirdGenre?.toLowerCase().includes('competitive') ||
        game.thirdGenre?.toLowerCase().includes('online');
      
      if (multiplayer === 'yes' && gameHasMultiplayer) {
        score += 15;
        reasons.push(`Has multiplayer features`);
      } else if (multiplayer === 'no' && !gameHasMultiplayer) {
        score += 15;
        reasons.push(`Single-player focused`);
      } else if (multiplayer === 'both') {
        score += 10;
      } else if (!multiplayer) {
        score += 7;
      }

      // Story importance (10 points)
      maxScore += 10;
      const gameHasStory = 
        game.secondaryGenres?.toLowerCase().includes('story') ||
        game.thirdGenre?.toLowerCase().includes('story') ||
        game.thirdGenre?.toLowerCase().includes('narrative') ||
        game.primaryGenre?.toLowerCase().includes('adventure') ||
        game.primaryGenre?.toLowerCase().includes('rpg');
      
      if (storyImportance === 'high' && gameHasStory) {
        score += 10;
        reasons.push(`Rich story experience`);
      } else if (storyImportance === 'low' && !gameHasStory) {
        score += 10;
        reasons.push(`Gameplay-focused`);
      } else if (storyImportance === 'medium') {
        score += 7;
      } else if (!storyImportance) {
        score += 5;
      }

      // Difficulty preference (10 points)
      maxScore += 10;
      const gameIsChallenging = 
        game.secondaryGenres?.toLowerCase().includes('soulsborne') ||
        game.thirdGenre?.toLowerCase().includes('challenging') ||
        game.thirdGenre?.toLowerCase().includes('competitive');
      const gameIsCasual = 
        game.primaryGenre?.toLowerCase().includes('casual') ||
        game.thirdGenre?.toLowerCase().includes('casual') ||
        game.primaryGenre?.toLowerCase().includes('simulation');
      
      if (difficulty === 'hard' && gameIsChallenging) {
        score += 10;
        reasons.push(`Challenging gameplay`);
      } else if (difficulty === 'easy' && gameIsCasual) {
        score += 10;
        reasons.push(`Casual-friendly`);
      } else if (difficulty === 'medium') {
        score += 7;
      } else if (!difficulty) {
        score += 5;
      }

      // Mood matching (10 points)
      maxScore += 10;
      const moodKeywords = {
        'relaxing': ['casual', 'simulation', 'farming', 'creative', 'sandbox'],
        'exciting': ['action', 'shooter', 'battle', 'combat', 'racing'],
        'scary': ['horror', 'survival', 'psychological'],
        'competitive': ['competitive', 'multiplayer', 'esports', 'pvp'],
        'immersive': ['open-world', 'rpg', 'adventure', 'story', 'narrative']
      };
      
      if (mood && moodKeywords[mood]) {
        const gameText = `${game.primaryGenre} ${game.secondaryGenres} ${game.thirdGenre}`.toLowerCase();
        const moodMatch = moodKeywords[mood].some(keyword => gameText.includes(keyword));
        if (moodMatch) {
          score += 10;
          reasons.push(`Matches your ${mood} mood`);
        }
      } else {
        score += 5;
      }

      // Rating bonus
      const ratingBonus = (game.rating / 100) * 10;
      score += ratingBonus;
      maxScore += 10;
      if (game.rating >= 90) {
        reasons.push(`Critically acclaimed (${game.rating}%)`);
      }

      const matchPercentage = Math.round((score / maxScore) * 100);

      return {
        ...game,
        matchPercentage,
        reasons: reasons.slice(0, 3)
      };
    });

    const topGames = scoredGames
      .sort((a, b) => b.matchPercentage - a.matchPercentage)
      .slice(0, 5);

    setRecResults(topGames);
    setRecSetup(prev => ({ ...prev, completed: true }));
  };

  const resetRecommendationSetup = () => {
    setRecSetup({
      step: 1,
      genres: [],
      platform: '',
      multiplayer: '',
      storyImportance: '',
      difficulty: '',
      mood: '',
      completed: false
    });
    setRecResults([]);
  };

  // ==================== FILTER FUNCTIONS ====================

  const filterByTag = (tag) => {
    if (!tag) {
      setFilteredGames(games);
      return;
    }
    const filtered = games.filter(g => 
      g.secondaryGenres?.toLowerCase().includes(tag.toLowerCase()) ||
      g.thirdGenre?.toLowerCase().includes(tag.toLowerCase())
    );
    setFilteredGames(filtered);
  };

  const applyAdvancedFilters = () => {
    let filtered = [...games];
    
    if (advancedFilters.genre) {
      filtered = filtered.filter(g => g.primaryGenre === advancedFilters.genre);
    }
    if (advancedFilters.platform) {
      filtered = filtered.filter(g => g.platforms?.includes(advancedFilters.platform));
    }
    if (advancedFilters.minRating > 0) {
      filtered = filtered.filter(g => g.rating >= advancedFilters.minRating);
    }
    if (advancedFilters.minYear) {
      filtered = filtered.filter(g => g.year >= advancedFilters.minYear);
    }
    if (advancedFilters.maxYear) {
      filtered = filtered.filter(g => g.year <= advancedFilters.maxYear);
    }
    
    setFilteredGames(filtered);
  };

  const describeWhatIWant = (description) => {
    const desc = description.toLowerCase();
    
    const keywords = {
      'action': ['action', 'fight', 'combat', 'battle'],
      'rpg': ['rpg', 'role-playing', 'level up', 'character'],
      'shooter': ['shooter', 'fps', 'gun', 'shoot'],
      'horror': ['horror', 'scary', 'fear', 'creepy', 'terrifying'],
      'adventure': ['adventure', 'explore', 'journey', 'quest'],
      'strategy': ['strategy', 'tactical', 'think', 'plan'],
      'simulation': ['simulation', 'sim', 'realistic', 'manage'],
      'racing': ['racing', 'car', 'drive', 'speed', 'fast'],
      'sports': ['sports', 'football', 'soccer', 'basketball', 'athletic'],
      'puzzle': ['puzzle', 'brain', 'solve', 'logic'],
      'multiplayer': ['multiplayer', 'friends', 'online', 'coop', 'co-op', 'together'],
      'story': ['story', 'narrative', 'plot', 'cinematic'],
      'open-world': ['open-world', 'open world', 'sandbox', 'explore', 'freedom'],
      'competitive': ['competitive', 'esports', 'ranked', 'pvp'],
      'relaxing': ['relaxing', 'chill', 'calm', 'peaceful', 'casual'],
      'challenging': ['challenging', 'hard', 'difficult', 'souls', 'hardcore']
    };
    
    let scores = {};
    games.forEach(game => {
      let score = 0;
      const gameText = `${game.primaryGenre} ${game.secondaryGenres} ${game.thirdGenre}`.toLowerCase();
      
      Object.entries(keywords).forEach(([category, words]) => {
        words.forEach(word => {
          if (desc.includes(word)) {
            if (gameText.includes(category) || gameText.includes(word)) {
              score += 10;
            }
          }
        });
      });
      
      score += game.rating / 20;
      
      if (score > 0) {
        scores[game.gameId] = score;
      }
    });
    
    const sorted = games
      .filter(g => scores[g.gameId] > 0)
      .sort((a, b) => scores[b.gameId] - scores[a.gameId]);
    
    setFilteredGames(sorted.length > 0 ? sorted : games);
  };

  // ==================== AUTH & PROFILE ====================

  const handleAuth = () => {
    if (authMode === 'guest') {
      const guestUser = { username: 'Guest', email: 'guest@levelup.com', isGuest: true };
      setUser(guestUser);
      setCurrentPage('home');
      setShowAuth(false);
      return;
    }
    
    if (!authEmail || !authPassword) {
      alert('Please fill in all fields');
      return;
    }

    if (authMode === 'signup') {
      // Check if user already exists
      const existingProfile = getUserProfile(authEmail);
      if (existingProfile) {
        alert('An account with this email already exists. Please sign in.');
        setAuthMode('signin');
        return;
      }
    }

    if (authMode === 'signin') {
      // Check if profile exists
      const profile = getUserProfile(authEmail);
      if (!profile) {
        alert('No account found with this email. Please sign up first.');
        setAuthMode('signup');
        return;
      }
    }
    
    const username = authUsername || authEmail.split('@')[0];
    const userData = { username, email: authEmail, isGuest: false };
    
    // Save user session
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(userData));
    
    // Initialize profile if new user
    if (authMode === 'signup') {
      saveUserProfile(authEmail, {
        username,
        email: authEmail,
        favorites: [],
        playHistory: [],
        createdAt: new Date().toISOString()
      });
    }
    
    setUser(userData);
    loadUserData(authEmail);
    setCurrentPage('home');
    setShowAuth(false);
    setAuthEmail('');
    setAuthPassword('');
    setAuthUsername('');
  };

  const handleLogout = () => {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    setUser(null);
    setCurrentPage('landing');
    setFavorites([]);
    setPlayHistory([]);
    setRecommendations([]);
    setFavoriteBasedRecs([]);
  };

  const updateProfile = () => {
    if (!profileForm.username.trim()) {
      alert('Username cannot be empty');
      return;
    }
    
    const updatedUser = { ...user, username: profileForm.username };
    setUser(updatedUser);
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(updatedUser));
    saveUserProfile(user.email, { username: profileForm.username });
    setEditingProfile(false);
  };

  const deleteAccount = () => {
    if (confirm('Are you sure you want to delete your account? This cannot be undone.')) {
      const profiles = loadProfiles();
      delete profiles[user.email];
      saveProfiles(profiles);
      handleLogout();
    }
  };

  // ==================== COMPONENTS ====================

  const Sidebar = () => (
    <aside className={`fixed left-0 top-0 h-full w-64 bg-black/40 backdrop-blur-xl border-r border-white/10 z-50 transform transition-transform ${showMobileMenu ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}>
      <div className="p-6 h-full flex flex-col">
        <div className="flex items-center gap-2 mb-8">
          <Gamepad2 className="w-8 h-8 text-purple-400" />
          <span className="text-2xl font-bold">LevelUp</span>
        </div>
        
        <nav className="space-y-2 flex-1">
          <NavItem icon={Home} label="Home" page="home" />
          <NavItem icon={Sparkles} label="Get Recommendations" page="recommendations" />
          <NavItem icon={Heart} label={`Favorites (${favorites.length})`} page="favorites" />
          <NavItem icon={Filter} label="Search by Genre" page="genre" />
          <NavItem icon={Tag} label="Search by Tag" page="tag" />
          <NavItem icon={Type} label="Search by Title" page="title" />
          <NavItem icon={Sliders} label="Advanced Search" page="advanced" />
          <NavItem icon={MessageSquare} label="Describe What I Want" page="describe" />
          <NavItem icon={Library} label="Browse All Games" page="browse" />
          
          <div className="border-t border-white/10 my-4" />
          
          <NavItem icon={UserCircle} label="My Profile" page="profile" />
        </nav>
        
        <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm ${isConnected ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
          {isConnected ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
          {isConnected ? 'Connected' : 'Disconnected'}
        </div>
      </div>
    </aside>
  );

  const NavItem = ({ icon: Icon, label, page }) => (
    <button
      onClick={() => { setCurrentPage(page); setShowMobileMenu(false); }}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition ${
        currentPage === page 
          ? 'bg-purple-600 text-white' 
          : 'text-purple-200 hover:bg-white/10'
      }`}
    >
      <Icon className="w-5 h-5" />
      <span className="text-sm">{label}</span>
    </button>
  );

  const GameCard = ({ game, showMatch = false }) => (
    <div
      className="bg-white/10 backdrop-blur-md rounded-xl overflow-hidden border border-white/20 hover:border-purple-500/50 transition hover:shadow-xl hover:shadow-purple-500/20 group cursor-pointer"
      onClick={() => addToHistory(game)}
    >
      <div className="bg-gradient-to-br from-purple-600 to-pink-600 h-32 flex items-center justify-center relative">
        <div className="text-center">
          {showMatch && game.matchPercentage ? (
            <>
              <p className="text-3xl font-bold text-white/90">{game.matchPercentage}%</p>
              <p className="text-xs text-white/70">Match</p>
            </>
          ) : (
            <>
              <p className="text-3xl font-bold text-white/90">{game.rating}</p>
              <p className="text-xs text-white/70">Rating</p>
            </>
          )}
        </div>
        {!user?.isGuest && (
          <button
            onClick={(e) => { e.stopPropagation(); toggleFavorite(game); }}
            className="absolute top-2 right-2 p-1 rounded-full hover:bg-white/20 transition"
          >
            <Heart className={`w-5 h-5 transition ${
              isFavorite(game.gameId)
                ? 'fill-red-500 text-red-500'
                : 'text-white/40 hover:text-red-400'
            }`} />
          </button>
        )}
      </div>
      
      <div className="p-4">
        <h4 className="font-bold text-lg mb-2 group-hover:text-purple-300 transition truncate">
          {game.title}
        </h4>
        
        <div className="flex flex-wrap gap-1 mb-2">
          <span className="px-2 py-0.5 bg-purple-500/30 rounded text-xs">{game.primaryGenre}</span>
          {game.secondaryGenres && (
            <span className="px-2 py-0.5 bg-pink-500/30 rounded text-xs">{game.secondaryGenres}</span>
          )}
        </div>
        
        <div className="flex justify-between text-xs text-purple-300">
          <span>{game.year}</span>
          <span className="truncate ml-2">{game.platforms?.split(' / ')[0]}</span>
        </div>

        {showMatch && game.reasons && game.reasons.length > 0 && (
          <div className="mt-3 pt-3 border-t border-white/10">
            <p className="text-xs text-purple-400 flex items-center gap-1">
              <ThumbsUp className="w-3 h-3" /> {game.reasons[0]}
            </p>
          </div>
        )}
      </div>
    </div>
  );

  const PageHeader = ({ icon: Icon, title, subtitle, action }) => (
    <div className="mb-8 flex items-start justify-between">
      <div className="flex items-center gap-3">
        <div className="p-3 bg-purple-600/30 rounded-xl">
          <Icon className="w-6 h-6 text-purple-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">{title}</h1>
          {subtitle && <p className="text-purple-300 text-sm">{subtitle}</p>}
        </div>
      </div>
      {action}
    </div>
  );

  const ResultsGrid = ({ title, count, games: gamesList, showMatch = false }) => {
    const displayGames = gamesList || filteredGames;
    
    return (
      <>
        {title && (
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">{title}</h3>
            <span className="text-purple-400">{count || displayGames.length} games</span>
          </div>
        )}
        
        {isLoading ? (
          <div className="text-center py-12">
            <RefreshCw className="w-12 h-12 mx-auto text-purple-400 animate-spin mb-4" />
            <p className="text-purple-300">Loading games...</p>
          </div>
        ) : displayGames.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {displayGames.map(game => (
              <GameCard key={game.gameId} game={game} showMatch={showMatch} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-purple-300">
            <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No games found</p>
          </div>
        )}
      </>
    );
  };

  // ==================== RECOMMENDATION SETUP COMPONENT ====================

  const RecommendationSetup = () => {
    const totalSteps = 6;

    const QuestionCard = ({ icon: Icon, title, children }) => (
      <div className="bg-white/5 rounded-2xl p-8 border border-white/10 max-w-2xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-purple-600/30 rounded-xl">
            <Icon className="w-6 h-6 text-purple-400" />
          </div>
          <h2 className="text-xl font-bold">{title}</h2>
        </div>
        {children}
      </div>
    );

    const ProgressBar = () => (
      <div className="mb-8">
        <div className="flex justify-between text-sm text-purple-300 mb-2">
          <span>Step {recSetup.step} of {totalSteps}</span>
          <span>{Math.round((recSetup.step / totalSteps) * 100)}% Complete</span>
        </div>
        <div className="h-2 bg-white/10 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-purple-600 to-pink-600 transition-all duration-300"
            style={{ width: `${(recSetup.step / totalSteps) * 100}%` }}
          />
        </div>
      </div>
    );

    const NavigationButtons = ({ canProceed = true }) => (
      <div className="flex justify-between mt-8">
        <button
          onClick={() => setRecSetup(prev => ({ ...prev, step: prev.step - 1 }))}
          disabled={recSetup.step === 1}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl transition ${
            recSetup.step === 1 ? 'opacity-50 cursor-not-allowed' : 'bg-white/10 hover:bg-white/20'
          }`}
        >
          <ChevronLeft className="w-5 h-5" /> Back
        </button>
        
        {recSetup.step < totalSteps ? (
          <button
            onClick={() => setRecSetup(prev => ({ ...prev, step: prev.step + 1 }))}
            disabled={!canProceed}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl transition ${
              canProceed ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:opacity-90' : 'opacity-50 cursor-not-allowed bg-white/10'
            }`}
          >
            Next <ChevronRight className="w-5 h-5" />
          </button>
        ) : (
          <button
            onClick={calculateRecommendations}
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-green-600 to-teal-600 rounded-xl hover:opacity-90 transition"
          >
            <Sparkles className="w-5 h-5" /> Get My Recommendations
          </button>
        )}
      </div>
    );

    return (
      <div className="max-w-3xl mx-auto">
        <ProgressBar />

        {recSetup.step === 1 && (
          <QuestionCard icon={Gamepad2} title="What genres do you enjoy?">
            <p className="text-purple-300 mb-4">Select all that apply (at least 1)</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {genres.slice(0, 12).map(genre => (
                <button
                  key={genre}
                  onClick={() => {
                    setRecSetup(prev => ({
                      ...prev,
                      genres: prev.genres.includes(genre)
                        ? prev.genres.filter(g => g !== genre)
                        : [...prev.genres, genre]
                    }));
                  }}
                  className={`p-3 rounded-xl border-2 transition relative ${
                    recSetup.genres.includes(genre)
                      ? 'border-purple-500 bg-purple-500/20'
                      : 'border-white/20 hover:border-white/40 bg-white/5'
                  }`}
                >
                  {genre}
                  {recSetup.genres.includes(genre) && (
                    <Check className="w-4 h-4 text-purple-400 absolute top-1 right-1" />
                  )}
                </button>
              ))}
            </div>
            <NavigationButtons canProceed={recSetup.genres.length > 0} />
          </QuestionCard>
        )}

        {recSetup.step === 2 && (
          <QuestionCard icon={Database} title="What platform do you play on?">
            <p className="text-purple-300 mb-4">Select your primary gaming platform</p>
            <div className="grid grid-cols-2 gap-3">
              {platforms.map(platform => (
                <button
                  key={platform}
                  onClick={() => setRecSetup(prev => ({ ...prev, platform }))}
                  className={`p-4 rounded-xl border-2 transition relative ${
                    recSetup.platform === platform ? 'border-purple-500 bg-purple-500/20' : 'border-white/20 hover:border-white/40 bg-white/5'
                  }`}
                >
                  {platform}
                  {recSetup.platform === platform && <Check className="w-4 h-4 text-purple-400 absolute top-2 right-2" />}
                </button>
              ))}
              <button
                onClick={() => setRecSetup(prev => ({ ...prev, platform: '' }))}
                className={`p-4 rounded-xl border-2 transition ${recSetup.platform === '' ? 'border-purple-500 bg-purple-500/20' : 'border-white/20 hover:border-white/40 bg-white/5'}`}
              >
                Any Platform
              </button>
            </div>
            <NavigationButtons />
          </QuestionCard>
        )}

        {recSetup.step === 3 && (
          <QuestionCard icon={Users} title="Do you prefer multiplayer or single-player?">
            <div className="grid gap-4">
              {[
                { value: 'yes', label: 'Multiplayer', desc: 'I want to play with friends or online' },
                { value: 'no', label: 'Single-player', desc: 'I prefer solo gaming experiences' },
                { value: 'both', label: 'Both', desc: 'I enjoy both equally' }
              ].map(option => (
                <button
                  key={option.value}
                  onClick={() => setRecSetup(prev => ({ ...prev, multiplayer: option.value }))}
                  className={`p-4 rounded-xl border-2 transition text-left relative ${
                    recSetup.multiplayer === option.value ? 'border-purple-500 bg-purple-500/20' : 'border-white/20 hover:border-white/40 bg-white/5'
                  }`}
                >
                  <p className="font-bold">{option.label}</p>
                  <p className="text-sm text-purple-300">{option.desc}</p>
                  {recSetup.multiplayer === option.value && <Check className="w-5 h-5 text-purple-400 absolute top-4 right-4" />}
                </button>
              ))}
            </div>
            <NavigationButtons />
          </QuestionCard>
        )}

        {recSetup.step === 4 && (
          <QuestionCard icon={BookOpen} title="How important is the story?">
            <div className="grid gap-4">
              {[
                { value: 'high', label: 'Very Important', desc: 'I love narrative-driven games with deep stories' },
                { value: 'medium', label: 'Somewhat Important', desc: 'A good story is nice but not required' },
                { value: 'low', label: 'Not Important', desc: 'I care more about gameplay than story' }
              ].map(option => (
                <button
                  key={option.value}
                  onClick={() => setRecSetup(prev => ({ ...prev, storyImportance: option.value }))}
                  className={`p-4 rounded-xl border-2 transition text-left relative ${
                    recSetup.storyImportance === option.value ? 'border-purple-500 bg-purple-500/20' : 'border-white/20 hover:border-white/40 bg-white/5'
                  }`}
                >
                  <p className="font-bold">{option.label}</p>
                  <p className="text-sm text-purple-300">{option.desc}</p>
                  {recSetup.storyImportance === option.value && <Check className="w-5 h-5 text-purple-400 absolute top-4 right-4" />}
                </button>
              ))}
            </div>
            <NavigationButtons />
          </QuestionCard>
        )}

        {recSetup.step === 5 && (
          <QuestionCard icon={Target} title="What difficulty level do you prefer?">
            <div className="grid gap-4">
              {[
                { value: 'easy', label: 'Casual / Easy', desc: 'Relaxing gameplay, no stress' },
                { value: 'medium', label: 'Balanced', desc: 'Some challenge but not too hard' },
                { value: 'hard', label: 'Challenging', desc: 'I love difficult, rewarding games' }
              ].map(option => (
                <button
                  key={option.value}
                  onClick={() => setRecSetup(prev => ({ ...prev, difficulty: option.value }))}
                  className={`p-4 rounded-xl border-2 transition text-left relative ${
                    recSetup.difficulty === option.value ? 'border-purple-500 bg-purple-500/20' : 'border-white/20 hover:border-white/40 bg-white/5'
                  }`}
                >
                  <p className="font-bold">{option.label}</p>
                  <p className="text-sm text-purple-300">{option.desc}</p>
                  {recSetup.difficulty === option.value && <Check className="w-5 h-5 text-purple-400 absolute top-4 right-4" />}
                </button>
              ))}
            </div>
            <NavigationButtons />
          </QuestionCard>
        )}

        {recSetup.step === 6 && (
          <QuestionCard icon={Heart} title="What's your current gaming mood?">
            <div className="grid grid-cols-2 gap-4">
              {[
                { value: 'relaxing', label: '😌 Relaxing', desc: 'Chill and unwind' },
                { value: 'exciting', label: '🔥 Exciting', desc: 'Action and adrenaline' },
                { value: 'scary', label: '😱 Scary', desc: 'Horror and thrills' },
                { value: 'competitive', label: '🏆 Competitive', desc: 'Test my skills' },
                { value: 'immersive', label: '🌍 Immersive', desc: 'Get lost in a world' }
              ].map(option => (
                <button
                  key={option.value}
                  onClick={() => setRecSetup(prev => ({ ...prev, mood: option.value }))}
                  className={`p-4 rounded-xl border-2 transition text-left relative ${
                    recSetup.mood === option.value ? 'border-purple-500 bg-purple-500/20' : 'border-white/20 hover:border-white/40 bg-white/5'
                  }`}
                >
                  <p className="font-bold text-lg">{option.label}</p>
                  <p className="text-sm text-purple-300">{option.desc}</p>
                  {recSetup.mood === option.value && <Check className="w-5 h-5 text-purple-400 absolute top-2 right-2" />}
                </button>
              ))}
            </div>
            <NavigationButtons />
          </QuestionCard>
        )}
      </div>
    );
  };

  // Recommendation Results Component
  const RecommendationResults = () => (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <Sparkles className="w-16 h-16 text-purple-400 mx-auto mb-4" />
        <h2 className="text-3xl font-bold mb-2">Your Top 5 Recommendations</h2>
        <p className="text-purple-300">Based on your preferences</p>
      </div>

      <div className="space-y-4">
        {recResults.map((game, index) => (
          <div key={game.gameId} className="bg-white/10 backdrop-blur-md rounded-2xl overflow-hidden border border-white/20">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-32 bg-gradient-to-br from-purple-600 to-pink-600 p-6 flex flex-col items-center justify-center">
                <span className="text-4xl font-bold">#{index + 1}</span>
                <div className="mt-2 flex items-center gap-1">
                  <Percent className="w-4 h-4" />
                  <span className="text-xl font-bold">{game.matchPercentage}%</span>
                </div>
              </div>

              <div className="flex-1 p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-2xl font-bold mb-2">{game.title}</h3>
                    <div className="flex flex-wrap gap-2 mb-3">
                      <span className="px-3 py-1 bg-purple-500/30 rounded-full text-sm">{game.primaryGenre}</span>
                      {game.secondaryGenres && <span className="px-3 py-1 bg-pink-500/30 rounded-full text-sm">{game.secondaryGenres}</span>}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-purple-300 mb-4">
                      <span>📅 {game.year}</span>
                      <span>⭐ {game.rating}/100</span>
                    </div>
                    <div className="bg-white/5 rounded-xl p-4">
                      <p className="text-sm font-semibold text-purple-400 mb-2 flex items-center gap-2">
                        <ThumbsUp className="w-4 h-4" /> Why you'll like it:
                      </p>
                      <ul className="space-y-1">
                        {game.reasons.map((reason, i) => (
                          <li key={i} className="text-sm text-purple-200 flex items-center gap-2">
                            <Zap className="w-3 h-3 text-yellow-400" /> {reason}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleFavorite(game)}
                    className="p-2 hover:bg-white/10 rounded-lg transition"
                  >
                    <Heart className={`w-6 h-6 ${isFavorite(game.gameId) ? 'fill-red-500 text-red-500' : 'text-white/40'}`} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 text-center">
        <button onClick={resetRecommendationSetup}
          className="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl font-bold hover:opacity-90 transition">
          Get New Recommendations
        </button>
      </div>
    </div>
  );

  // ==================== LANDING PAGE ====================

  if (currentPage === 'landing') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white">
        <div className="container mx-auto px-4 py-20">
          <div className="text-center max-w-4xl mx-auto">
            <div className="flex items-center justify-center gap-3 mb-8">
              <Gamepad2 className="w-16 h-16 text-purple-400" />
              <h1 className="text-6xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                LevelUp
              </h1>
            </div>

            <p className="text-xl text-purple-200 mb-8">
              AI-Powered Game Recommendations • Discover Your Next Adventure
            </p>

            <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8 ${isConnected ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
              {isConnected ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
              {isConnected ? `Connected • ${games.length} games` : 'Backend Offline'}
            </div>

            {error && (
              <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-4 mb-8 text-red-300">
                <p>{error}</p>
                <button onClick={fetchGames} className="mt-2 flex items-center gap-2 mx-auto px-4 py-2 bg-red-500/30 rounded hover:bg-red-500/50">
                  <RefreshCw className="w-4 h-4" /> Retry
                </button>
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button onClick={() => setShowAuth(true)}
                className="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl font-bold text-lg hover:from-purple-500 hover:to-pink-500 transition shadow-lg">
                Get Started
              </button>
              <button onClick={() => { setUser({ username: 'Guest', email: 'guest@levelup.com', isGuest: true }); setCurrentPage('home'); }}
                className="px-8 py-4 bg-white/10 rounded-xl font-bold text-lg hover:bg-white/20 transition border border-white/20">
                Continue as Guest
              </button>
            </div>

            <div className="grid md:grid-cols-4 gap-4 mt-16">
              {[
                { icon: Sparkles, title: 'Smart Recommendations', desc: 'AI-powered suggestions' },
                { icon: Heart, title: 'Save Favorites', desc: 'Build your collection' },
                { icon: UserCircle, title: 'Profile System', desc: 'Your data saved' },
                { icon: Database, title: '119+ Games', desc: 'Curated database' }
              ].map((f, i) => (
                <div key={i} className="bg-white/5 rounded-xl p-4 border border-white/10">
                  <f.icon className="w-8 h-8 text-purple-400 mb-2 mx-auto" />
                  <h3 className="font-bold">{f.title}</h3>
                  <p className="text-sm text-purple-300">{f.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {showAuth && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
            <div className="bg-gray-900 rounded-2xl p-8 max-w-md w-full border border-purple-500/30">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Welcome</h2>
                <button onClick={() => setShowAuth(false)}><X className="w-6 h-6" /></button>
              </div>

              <div className="flex gap-2 mb-6">
                {['signin', 'signup', 'guest'].map(mode => (
                  <button key={mode} onClick={() => setAuthMode(mode)}
                    className={`flex-1 py-2 rounded-lg transition ${authMode === mode ? 'bg-purple-600' : 'bg-white/10 hover:bg-white/20'}`}>
                    {mode === 'signin' ? 'Sign In' : mode === 'signup' ? 'Sign Up' : 'Guest'}
                  </button>
                ))}
              </div>

              {authMode !== 'guest' ? (
                <div className="space-y-4">
                  {authMode === 'signup' && (
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-purple-400" />
                      <input type="text" placeholder="Username" value={authUsername} onChange={(e) => setAuthUsername(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-white/10 rounded-lg border border-white/20 focus:border-purple-500 focus:outline-none" />
                    </div>
                  )}
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-purple-400" />
                    <input type="email" placeholder="Email" value={authEmail} onChange={(e) => setAuthEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-white/10 rounded-lg border border-white/20 focus:border-purple-500 focus:outline-none" />
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-purple-400" />
                    <input type="password" placeholder="Password" value={authPassword} onChange={(e) => setAuthPassword(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-white/10 rounded-lg border border-white/20 focus:border-purple-500 focus:outline-none" />
                  </div>
                  {authMode === 'signup' && (
                    <p className="text-xs text-purple-300">Your profile and favorites will be saved locally</p>
                  )}
                </div>
              ) : (
                <p className="text-purple-300 mb-4">Continue without an account. Favorites won't be saved.</p>
              )}

              <button onClick={handleAuth}
                className="w-full mt-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg font-bold hover:from-purple-500 hover:to-pink-500">
                {authMode === 'guest' ? 'Continue as Guest' : authMode === 'signin' ? 'Sign In' : 'Create Account'}
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ==================== MAIN APP LAYOUT ====================

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white">
      <Sidebar />
      
      <button onClick={() => setShowMobileMenu(!showMobileMenu)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-purple-600 rounded-lg">
        <Menu className="w-6 h-6" />
      </button>

      {showMobileMenu && (
        <div className="lg:hidden fixed inset-0 bg-black/50 z-40" onClick={() => setShowMobileMenu(false)} />
      )}

      <main className="lg:ml-64 p-6">
        <header className="flex justify-between items-center mb-8">
          <div className="lg:hidden w-10" />
          
          <div className="flex items-center gap-4 ml-auto">
            <button onClick={fetchGames} className="p-2 hover:bg-white/10 rounded-lg" title="Refresh">
              <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
            
            {user && (
              <div className="flex items-center gap-3">
                <button onClick={() => setCurrentPage('profile')} className="flex items-center gap-2 px-3 py-2 bg-white/10 rounded-lg hover:bg-white/20 transition">
                  <UserCircle className="w-4 h-4" />
                  <span className="text-sm">{user.username}</span>
                  {!user.isGuest && <Crown className="w-3 h-3 text-yellow-400" />}
                </button>
                <button onClick={handleLogout} className="p-2 hover:bg-white/10 rounded-lg" title="Logout">
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            )}
          </div>
        </header>

        {/* HOME PAGE */}
        {currentPage === 'home' && (
          <div>
            <PageHeader icon={Home} title="Welcome back!" subtitle={`Hello, ${user?.username}`} />
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="bg-white/10 rounded-xl p-4 text-center">
                <p className="text-3xl font-bold text-purple-400">{games.length}</p>
                <p className="text-sm text-purple-300">Total Games</p>
              </div>
              <div className="bg-white/10 rounded-xl p-4 text-center">
                <p className="text-3xl font-bold text-red-400">{favorites.length}</p>
                <p className="text-sm text-purple-300">Favorites</p>
              </div>
              <div className="bg-white/10 rounded-xl p-4 text-center">
                <p className="text-3xl font-bold text-pink-400">{genres.length}</p>
                <p className="text-sm text-purple-300">Genres</p>
              </div>
              <div className="bg-white/10 rounded-xl p-4 text-center">
                <p className="text-3xl font-bold text-green-400">{playHistory.length}</p>
                <p className="text-sm text-purple-300">Recently Viewed</p>
              </div>
            </div>

            {/* Favorite-Based Recommendations */}
            {favoriteBasedRecs.length > 0 && (
              <div className="mb-8">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-400" /> Based on Your Favorites
                </h3>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {favoriteBasedRecs.slice(0, 4).map(game => (
                    <GameCard key={game.gameId} game={game} showMatch={true} />
                  ))}
                </div>
                {favoriteBasedRecs.length > 4 && (
                  <button onClick={() => setCurrentPage('favorites')} className="mt-4 text-purple-400 hover:text-purple-300 text-sm">
                    View all {favoriteBasedRecs.length} recommendations →
                  </button>
                )}
              </div>
            )}

            {playHistory.length > 0 && (
              <div className="mb-8">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <History className="w-5 h-5 text-purple-400" /> Recently Viewed
                </h3>
                <div className="flex gap-4 overflow-x-auto pb-4">
                  {playHistory.slice(0, 6).map(game => (
                    <div key={game.gameId} className="flex-shrink-0 w-48 bg-white/10 rounded-lg p-3 border border-white/20">
                      <p className="font-semibold text-sm truncate">{game.title}</p>
                      <p className="text-xs text-purple-300">{game.primaryGenre}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { icon: Sparkles, label: 'Get Recommendations', page: 'recommendations', color: 'from-purple-600 to-pink-600' },
                { icon: Heart, label: 'My Favorites', page: 'favorites', color: 'from-red-600 to-pink-600' },
                { icon: Filter, label: 'Search by Genre', page: 'genre', color: 'from-blue-600 to-purple-600' },
                { icon: Library, label: 'Browse All Games', page: 'browse', color: 'from-green-600 to-teal-600' },
                { icon: MessageSquare, label: 'Describe What I Want', page: 'describe', color: 'from-pink-600 to-orange-600' },
                { icon: UserCircle, label: 'My Profile', page: 'profile', color: 'from-yellow-600 to-orange-600' }
              ].map((item, i) => (
                <button key={i} onClick={() => setCurrentPage(item.page)}
                  className={`bg-gradient-to-r ${item.color} p-6 rounded-xl text-left hover:opacity-90 transition group`}>
                  <item.icon className="w-8 h-8 mb-2" />
                  <p className="font-bold text-lg">{item.label}</p>
                  <ChevronRight className="w-5 h-5 mt-2 opacity-50 group-hover:translate-x-1 transition" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* FAVORITES PAGE */}
        {currentPage === 'favorites' && (
          <div>
            <PageHeader 
              icon={Heart} 
              title="My Favorites" 
              subtitle={`${favorites.length} games saved`}
              action={
                favorites.length > 0 && (
                  <button onClick={clearAllFavorites} className="flex items-center gap-2 px-4 py-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition">
                    <Trash2 className="w-4 h-4" /> Clear All
                  </button>
                )
              }
            />

            {user?.isGuest && (
              <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-lg p-4 mb-6 text-yellow-200">
                <p className="flex items-center gap-2">
                  <Crown className="w-5 h-5" />
                  <span>Sign up to save your favorites permanently!</span>
                </p>
              </div>
            )}

            {favorites.length === 0 ? (
              <div className="text-center py-16">
                <Heart className="w-16 h-16 mx-auto text-purple-400/50 mb-4" />
                <h3 className="text-xl font-bold mb-2">No favorites yet</h3>
                <p className="text-purple-300 mb-6">Click the heart icon on any game to add it to your favorites</p>
                <button onClick={() => setCurrentPage('browse')} className="px-6 py-3 bg-purple-600 rounded-xl hover:bg-purple-500 transition">
                  Browse Games
                </button>
              </div>
            ) : (
              <>
                <ResultsGrid title="Your Favorited Games" games={favorites} />
                
                {favoriteBasedRecs.length > 0 && (
                  <div className="mt-12">
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-purple-400" /> 
                      Recommended Based on Your Favorites
                    </h3>
                    <p className="text-purple-300 mb-6">Games similar to the ones you love</p>
                    <ResultsGrid games={favoriteBasedRecs} showMatch={true} />
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* PROFILE PAGE */}
        {currentPage === 'profile' && (
          <div className="max-w-2xl mx-auto">
            <PageHeader icon={UserCircle} title="My Profile" subtitle="Manage your account" />

            <div className="bg-white/5 rounded-2xl p-8 border border-white/10 mb-6">
              <div className="flex items-center gap-6 mb-8">
                <div className="w-24 h-24 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center">
                  <span className="text-4xl font-bold">{user?.username?.charAt(0).toUpperCase()}</span>
                </div>
                <div>
                  <h2 className="text-2xl font-bold">{user?.username}</h2>
                  <p className="text-purple-300">{user?.email}</p>
                  {user?.isGuest ? (
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-yellow-500/20 text-yellow-400 rounded text-xs mt-2">
                      Guest Account
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-purple-500/20 text-purple-400 rounded text-xs mt-2">
                      <Crown className="w-3 h-3" /> Member
                    </span>
                  )}
                </div>
              </div>

              {!user?.isGuest && (
                <>
                  {editingProfile ? (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm text-purple-300 mb-2">Username</label>
                        <input
                          type="text"
                          value={profileForm.username}
                          onChange={(e) => setProfileForm({ ...profileForm, username: e.target.value })}
                          className="w-full px-4 py-3 bg-white/10 rounded-lg border border-white/20 focus:border-purple-500 focus:outline-none"
                        />
                      </div>
                      <div className="flex gap-3">
                        <button onClick={updateProfile} className="flex items-center gap-2 px-4 py-2 bg-green-600 rounded-lg hover:bg-green-500">
                          <Save className="w-4 h-4" /> Save
                        </button>
                        <button onClick={() => setEditingProfile(false)} className="px-4 py-2 bg-white/10 rounded-lg hover:bg-white/20">
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button onClick={() => { setProfileForm({ username: user.username, email: user.email }); setEditingProfile(true); }}
                      className="flex items-center gap-2 px-4 py-2 bg-white/10 rounded-lg hover:bg-white/20 transition">
                      <Edit className="w-4 h-4" /> Edit Profile
                    </button>
                  )}
                </>
              )}
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-white/5 rounded-xl p-6 border border-white/10 text-center">
                <Heart className="w-8 h-8 text-red-400 mx-auto mb-2" />
                <p className="text-3xl font-bold">{favorites.length}</p>
                <p className="text-purple-300 text-sm">Favorites</p>
              </div>
              <div className="bg-white/5 rounded-xl p-6 border border-white/10 text-center">
                <History className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                <p className="text-3xl font-bold">{playHistory.length}</p>
                <p className="text-purple-300 text-sm">Games Viewed</p>
              </div>
            </div>

            {/* Favorite Genres */}
            {favorites.length > 0 && (
              <div className="bg-white/5 rounded-xl p-6 border border-white/10 mb-6">
                <h3 className="font-bold mb-4 flex items-center gap-2">
                  <Award className="w-5 h-5 text-yellow-400" /> Your Favorite Genres
                </h3>
                <div className="flex flex-wrap gap-2">
                  {[...new Set(favorites.map(f => f.primaryGenre))].map(genre => (
                    <span key={genre} className="px-3 py-1 bg-purple-500/30 rounded-full text-sm">{genre}</span>
                  ))}
                </div>
              </div>
            )}

            {user?.isGuest ? (
              <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-xl p-6 border border-purple-500/30">
                <h3 className="font-bold mb-2">Want to save your progress?</h3>
                <p className="text-purple-300 text-sm mb-4">Create an account to keep your favorites and get personalized recommendations.</p>
                <button onClick={() => { setShowAuth(true); setAuthMode('signup'); setCurrentPage('landing'); }}
                  className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg font-bold hover:opacity-90">
                  Create Account
                </button>
              </div>
            ) : (
              <div className="bg-red-500/10 rounded-xl p-6 border border-red-500/30">
                <h3 className="font-bold text-red-400 mb-2">Danger Zone</h3>
                <p className="text-purple-300 text-sm mb-4">Permanently delete your account and all data.</p>
                <button onClick={deleteAccount} className="flex items-center gap-2 px-4 py-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30">
                  <Trash2 className="w-4 h-4" /> Delete Account
                </button>
              </div>
            )}
          </div>
        )}

        {/* RECOMMENDATIONS PAGE */}
        {currentPage === 'recommendations' && (
          <div>
            <PageHeader icon={Sparkles} title="Get Recommendations" subtitle="Answer questions or use your favorites" />
            
            {!recSetup.completed ? (
              <>
                {favorites.length > 0 && (
                  <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-xl p-6 border border-purple-500/30 mb-8 max-w-2xl mx-auto">
                    <h3 className="font-bold mb-2 flex items-center gap-2">
                      <Heart className="w-5 h-5 text-red-400" /> Quick Recommendations
                    </h3>
                    <p className="text-purple-300 text-sm mb-4">Get instant recommendations based on your {favorites.length} favorited games</p>
                    <button onClick={() => setCurrentPage('favorites')} className="px-6 py-3 bg-gradient-to-r from-red-600 to-pink-600 rounded-lg font-bold hover:opacity-90">
                      View Favorite-Based Recommendations
                    </button>
                  </div>
                )}
                <RecommendationSetup />
              </>
            ) : (
              <RecommendationResults />
            )}
          </div>
        )}

        {/* GENRE PAGE */}
        {currentPage === 'genre' && (
          <div>
            <PageHeader icon={Filter} title="Search by Genre" subtitle="Filter games by their primary genre" />
            <div className="flex flex-wrap gap-2 mb-6">
              <button onClick={() => { setSelectedGenre(''); setFilteredGames(games); }}
                className={`px-4 py-2 rounded-lg transition ${!selectedGenre ? 'bg-purple-600' : 'bg-white/10 hover:bg-white/20'}`}>All</button>
              {genres.map(genre => (
                <button key={genre} onClick={() => { setSelectedGenre(genre); searchByGenre(genre); }}
                  className={`px-4 py-2 rounded-lg transition ${selectedGenre === genre ? 'bg-purple-600' : 'bg-white/10 hover:bg-white/20'}`}>{genre}</button>
              ))}
            </div>
            <ResultsGrid title={selectedGenre ? `${selectedGenre} Games` : 'All Games'} />
          </div>
        )}

        {/* TAG PAGE */}
        {currentPage === 'tag' && (
          <div>
            <PageHeader icon={Tag} title="Search by Tag" subtitle="Find games by secondary categories" />
            <div className="flex flex-wrap gap-2 mb-6">
              <button onClick={() => { setSelectedTag(''); setFilteredGames(games); }}
                className={`px-4 py-2 rounded-lg transition ${!selectedTag ? 'bg-pink-600' : 'bg-white/10 hover:bg-white/20'}`}>All</button>
              {tags.slice(0, 30).map(tag => (
                <button key={tag} onClick={() => { setSelectedTag(tag); filterByTag(tag); }}
                  className={`px-4 py-2 rounded-lg transition ${selectedTag === tag ? 'bg-pink-600' : 'bg-white/10 hover:bg-white/20'}`}>{tag}</button>
              ))}
            </div>
            <ResultsGrid title={selectedTag ? `Games with "${selectedTag}"` : 'All Games'} />
          </div>
        )}

        {/* TITLE SEARCH PAGE */}
        {currentPage === 'title' && (
          <div>
            <PageHeader icon={Type} title="Search by Title" subtitle="Find games by name" />
            <div className="relative mb-6">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-purple-400" />
              <input type="text" placeholder="Enter game title..." value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); searchByTitle(e.target.value); }}
                className="w-full pl-12 pr-4 py-3 bg-white/10 rounded-xl border border-white/20 focus:border-purple-500 focus:outline-none" />
            </div>
            <ResultsGrid title={searchQuery ? `Results for "${searchQuery}"` : 'All Games'} />
          </div>
        )}

        {/* ADVANCED SEARCH PAGE */}
        {currentPage === 'advanced' && (
          <div>
            <PageHeader icon={Sliders} title="Advanced Search" subtitle="Use multiple filters" />
            <div className="bg-white/5 rounded-xl p-6 mb-6 border border-white/10">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm text-purple-300 mb-2">Genre</label>
                  <select value={advancedFilters.genre} onChange={(e) => setAdvancedFilters({...advancedFilters, genre: e.target.value})}
                    className="w-full px-4 py-2 bg-white/10 rounded-lg border border-white/20 focus:border-purple-500 focus:outline-none">
                    <option value="" className="bg-gray-900">Any Genre</option>
                    {genres.map(g => <option key={g} value={g} className="bg-gray-900">{g}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-purple-300 mb-2">Platform</label>
                  <select value={advancedFilters.platform} onChange={(e) => setAdvancedFilters({...advancedFilters, platform: e.target.value})}
                    className="w-full px-4 py-2 bg-white/10 rounded-lg border border-white/20 focus:border-purple-500 focus:outline-none">
                    <option value="" className="bg-gray-900">Any Platform</option>
                    {platforms.map(p => <option key={p} value={p} className="bg-gray-900">{p}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-purple-300 mb-2">Min Rating: {advancedFilters.minRating}</label>
                  <input type="range" min="0" max="100" value={advancedFilters.minRating}
                    onChange={(e) => setAdvancedFilters({...advancedFilters, minRating: parseInt(e.target.value)})} className="w-full" />
                </div>
                <div>
                  <label className="block text-sm text-purple-300 mb-2">Year From</label>
                  <input type="number" min="1980" max="2025" value={advancedFilters.minYear}
                    onChange={(e) => setAdvancedFilters({...advancedFilters, minYear: parseInt(e.target.value)})}
                    className="w-full px-4 py-2 bg-white/10 rounded-lg border border-white/20 focus:border-purple-500 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-sm text-purple-300 mb-2">Year To</label>
                  <input type="number" min="1980" max="2025" value={advancedFilters.maxYear}
                    onChange={(e) => setAdvancedFilters({...advancedFilters, maxYear: parseInt(e.target.value)})}
                    className="w-full px-4 py-2 bg-white/10 rounded-lg border border-white/20 focus:border-purple-500 focus:outline-none" />
                </div>
                <div className="flex items-end">
                  <button onClick={applyAdvancedFilters}
                    className="w-full px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg font-bold hover:opacity-90">Apply Filters</button>
                </div>
              </div>
              <button onClick={() => { setAdvancedFilters({ genre: '', platform: '', minRating: 0, maxYear: 2025, minYear: 2000 }); setFilteredGames(games); }}
                className="mt-4 text-purple-400 hover:text-purple-300 text-sm">Reset Filters</button>
            </div>
            <ResultsGrid title="Filtered Results" />
          </div>
        )}

        {/* DESCRIBE PAGE */}
        {currentPage === 'describe' && (
          <div>
            <PageHeader icon={MessageSquare} title="Describe What I Want" subtitle="Natural language search" />
            <div className="bg-white/5 rounded-xl p-6 mb-6 border border-white/10">
              <textarea placeholder="Example: I want a challenging action game with a good story..."
                value={describeText} onChange={(e) => setDescribeText(e.target.value)}
                className="w-full h-32 px-4 py-3 bg-white/10 rounded-lg border border-white/20 focus:border-purple-500 focus:outline-none resize-none" />
              <div className="flex flex-wrap gap-2 mt-4">
                <span className="text-sm text-purple-300">Try:</span>
                {['relaxing game to unwind', 'competitive shooter with friends', 'story-rich RPG', 'scary horror game'].map(s => (
                  <button key={s} onClick={() => { setDescribeText(s); describeWhatIWant(s); }}
                    className="px-3 py-1 bg-white/10 rounded-full text-sm hover:bg-white/20">{s}</button>
                ))}
              </div>
              <button onClick={() => describeWhatIWant(describeText)}
                className="mt-4 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg font-bold hover:opacity-90">Find Games</button>
            </div>
            <ResultsGrid title="Matching Games" />
          </div>
        )}

        {/* BROWSE ALL PAGE */}
        {currentPage === 'browse' && (
          <div>
            <PageHeader icon={Library} title="Browse All Games" subtitle={`${games.length} games`} />
            <div className="mb-6">
              <select onChange={(e) => {
                const sorted = [...games];
                switch(e.target.value) {
                  case 'rating': sorted.sort((a, b) => b.rating - a.rating); break;
                  case 'year': sorted.sort((a, b) => b.year - a.year); break;
                  case 'title': sorted.sort((a, b) => a.title.localeCompare(b.title)); break;
                  default: break;
                }
                setFilteredGames(sorted);
              }} className="px-4 py-2 bg-white/10 rounded-lg border border-white/20 focus:border-purple-500 focus:outline-none">
                <option value="" className="bg-gray-900">Sort by...</option>
                <option value="rating" className="bg-gray-900">Highest Rated</option>
                <option value="year" className="bg-gray-900">Newest First</option>
                <option value="title" className="bg-gray-900">A-Z</option>
              </select>
            </div>
            <ResultsGrid />
          </div>
        )}

      </main>
    </div>
  );
}

export default App;
