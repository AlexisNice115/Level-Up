# Game Recommender REST API

A Spring Boot REST API for the LevelUp Game Recommender.

## Requirements

- Java 17+
- Maven 3.6+
- MongoDB running on localhost:27017

## Quick Start

### 1. Start MongoDB

**macOS:**
```bash
brew services start mongodb-community
```

**Linux:**
```bash
sudo systemctl start mongod
```

**Windows:**
```bash
net start MongoDB
```

### 2. Run the API

```bash
cd game-recommender-api
mvn spring-boot:run
```

The API will start on **http://localhost:8080**

## API Endpoints

### Get Games

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/games` | Get all games |
| GET | `/api/games/{id}` | Get game by ID |
| GET | `/api/games/search?q=query` | Search games |
| GET | `/api/games/genre/{genre}` | Filter by genre |
| GET | `/api/games/platform/{platform}` | Filter by platform |
| GET | `/api/games/genres` | Get all genres |
| GET | `/api/games/count` | Get total count |

### Recommendations

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/games/recommend/{id}` | Get similar games |
| GET | `/api/games/recommend?genres=Action,RPG&minRating=80` | Get by preferences |

### Manage Games

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/games` | Create new game |
| PUT | `/api/games/{id}` | Update game |
| DELETE | `/api/games/{id}` | Delete game |

## Example Requests

### Get all games
```bash
curl http://localhost:8080/api/games
```

### Search games
```bash
curl "http://localhost:8080/api/games/search?q=zelda"
```

### Get recommendations for a game
```bash
curl http://localhost:8080/api/games/recommend/12
```

### Get recommendations by preferences
```bash
curl "http://localhost:8080/api/games/recommend?genres=RPG,Action&minRating=85&limit=5"
```

### Create a new game
```bash
curl -X POST http://localhost:8080/api/games \
  -H "Content-Type: application/json" \
  -d '{
    "title": "My New Game",
    "year": 2024,
    "primaryGenre": "RPG",
    "secondaryGenres": "Action",
    "thirdGenre": "Fantasy",
    "rating": 85,
    "platforms": "Steam"
  }'
```

## Connecting to React Frontend

Update your React code to fetch from the API:

```javascript
// Before (hardcoded)
const GAMES_DATABASE = [...];

// After (from API)
const [games, setGames] = useState([]);

useEffect(() => {
  fetch('http://localhost:8080/api/games')
    .then(res => res.json())
    .then(data => setGames(data));
}, []);
```

## Project Structure

```
game-recommender-api/
├── pom.xml
├── src/main/java/com/gamerecommender/
│   ├── GameRecommenderApplication.java  (Main)
│   ├── controller/
│   │   └── GameController.java          (REST endpoints)
│   ├── service/
│   │   └── GameService.java             (Business logic)
│   ├── repository/
│   │   └── GameRepository.java          (MongoDB queries)
│   ├── entity/
│   │   └── Game.java                    (Data model)
│   └── config/
│       ├── CorsConfig.java              (CORS settings)
│       └── DataLoader.java              (Loads 119 games)
└── src/main/resources/
    └── application.properties
```
