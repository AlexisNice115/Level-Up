package com.gamerecommender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameRecommenderApplication {

    public static void main(String[] args) {
        SpringApplication.run(GameRecommenderApplication.class, args);
    }
}
