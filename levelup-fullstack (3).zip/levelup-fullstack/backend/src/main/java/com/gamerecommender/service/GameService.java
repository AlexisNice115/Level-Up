package com.gamerecommender.service;

import com.gamerecommender.entity.Game;
import com.gamerecommender.repository.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class GameService {
    
    @Autowired
    private GameRepository gameRepository;
    
    // GET all games
    public List<Game> getAllGames() {
        return gameRepository.findAll();
    }
    
    // GET game by ID
    public Optional<Game> getGameById(Integer gameId) {
        return gameRepository.findByGameId(gameId);
    }
    
    // GET game by MongoDB ID
    public Optional<Game> getGameByMongoId(String id) {
        return gameRepository.findById(id);
    }
    
    // SEARCH games
    public List<Game> searchGames(String query) {
        return gameRepository.searchGames(query);
    }
    
    // GET by genre
    public List<Game> getGamesByGenre(String genre) {
        return gameRepository.findByAnyGenre(genre);
    }
    
    // GET by platform
    public List<Game> getGamesByPlatform(String platform) {
        return gameRepository.findByPlatformsContainingIgnoreCase(platform);
    }
    
    // GET by minimum rating
    public List<Game> getGamesByMinRating(Integer minRating) {
        return gameRepository.findByRatingGreaterThanEqual(minRating);
    }
    
    // GET recommendations based on a game
    public List<Game> getRecommendations(Integer gameId, int limit) {
        Optional<Game> gameOpt = gameRepository.findByGameId(gameId);
        if (gameOpt.isEmpty()) {
            return Collections.emptyList();
        }
        
        Game sourceGame = gameOpt.get();
        List<Game> allGames = gameRepository.findAll();
        
        // Score each game based on similarity
        return allGames.stream()
            .filter(g -> !g.getGameId().equals(gameId))
            .map(g -> new AbstractMap.SimpleEntry<>(g, calculateSimilarity(sourceGame, g)))
            .sorted((a, b) -> Double.compare(b.getValue(), a.getValue()))
            .limit(limit)
            .map(Map.Entry::getKey)
            .collect(Collectors.toList());
    }
    
    // GET recommendations based on preferences
    public List<Game> getRecommendationsByPreferences(List<String> genres, 
                                                       List<String> platforms,
                                                       Integer minRating,
                                                       int limit) {
        List<Game> allGames = gameRepository.findAll();
        
        return allGames.stream()
            .map(g -> new AbstractMap.SimpleEntry<>(g, scoreGame(g, genres, platforms, minRating)))
            .filter(e -> e.getValue() > 0)
            .sorted((a, b) -> Double.compare(b.getValue(), a.getValue()))
            .limit(limit)
            .map(Map.Entry::getKey)
            .collect(Collectors.toList());
    }
    
    // CREATE game
    public Game createGame(Game game) {
        // Auto-generate gameId if not provided
        if (game.getGameId() == null) {
            Integer maxId = gameRepository.findAll().stream()
                .map(Game::getGameId)
                .filter(Objects::nonNull)
                .max(Integer::compareTo)
                .orElse(0);
            game.setGameId(maxId + 1);
        }
        return gameRepository.save(game);
    }
    
    // UPDATE game
    public Optional<Game> updateGame(Integer gameId, Game updatedGame) {
        return gameRepository.findByGameId(gameId)
            .map(existingGame -> {
                if (updatedGame.getTitle() != null) existingGame.setTitle(updatedGame.getTitle());
                if (updatedGame.getYear() != null) existingGame.setYear(updatedGame.getYear());
                if (updatedGame.getPrimaryGenre() != null) existingGame.setPrimaryGenre(updatedGame.getPrimaryGenre());
                if (updatedGame.getSecondaryGenres() != null) existingGame.setSecondaryGenres(updatedGame.getSecondaryGenres());
                if (updatedGame.getThirdGenre() != null) existingGame.setThirdGenre(updatedGame.getThirdGenre());
                if (updatedGame.getRating() != null) existingGame.setRating(updatedGame.getRating());
                if (updatedGame.getPlatforms() != null) existingGame.setPlatforms(updatedGame.getPlatforms());
                return gameRepository.save(existingGame);
            });
    }
    
    // DELETE game
    public boolean deleteGame(Integer gameId) {
        return gameRepository.findByGameId(gameId)
            .map(game -> {
                gameRepository.delete(game);
                return true;
            })
            .orElse(false);
    }
    
    // DELETE all games
    public void deleteAllGames() {
        gameRepository.deleteAll();
    }
    
    // GET count
    public long getCount() {
        return gameRepository.count();
    }
    
    // GET all unique genres
    public List<String> getAllGenres() {
        return gameRepository.findAll().stream()
            .map(Game::getPrimaryGenre)
            .filter(Objects::nonNull)
            .distinct()
            .sorted()
            .collect(Collectors.toList());
    }
    
    // Calculate similarity between two games
    private double calculateSimilarity(Game g1, Game g2) {
        double score = 0;
        
        // Primary genre match
        if (g1.getPrimaryGenre() != null && g1.getPrimaryGenre().equalsIgnoreCase(g2.getPrimaryGenre())) {
            score += 30;
        }
        
        // Secondary genre match
        if (g1.getSecondaryGenres() != null && g1.getSecondaryGenres().equalsIgnoreCase(g2.getSecondaryGenres())) {
            score += 20;
        }
        
        // Third genre match
        if (g1.getThirdGenre() != null && g1.getThirdGenre().equalsIgnoreCase(g2.getThirdGenre())) {
            score += 15;
        }
        
        // Cross-genre matches
        if (g1.getPrimaryGenre() != null && 
            (g1.getPrimaryGenre().equalsIgnoreCase(g2.getSecondaryGenres()) ||
             g1.getPrimaryGenre().equalsIgnoreCase(g2.getThirdGenre()))) {
            score += 10;
        }
        
        // Rating similarity (closer = better)
        if (g1.getRating() != null && g2.getRating() != null) {
            int diff = Math.abs(g1.getRating() - g2.getRating());
            score += Math.max(0, 20 - diff);
        }
        
        // Year proximity bonus
        if (g1.getYear() != null && g2.getYear() != null) {
            int yearDiff = Math.abs(g1.getYear() - g2.getYear());
            score += Math.max(0, 10 - yearDiff);
        }
        
        return score;
    }
    
    // Score game based on preferences
    private double scoreGame(Game game, List<String> genres, List<String> platforms, Integer minRating) {
        double score = 0;
        
        // Genre matching
        if (genres != null && !genres.isEmpty()) {
            for (String genre : genres) {
                if (game.getPrimaryGenre() != null && 
                    game.getPrimaryGenre().toLowerCase().contains(genre.toLowerCase())) {
                    score += 30;
                }
                if (game.getSecondaryGenres() != null && 
                    game.getSecondaryGenres().toLowerCase().contains(genre.toLowerCase())) {
                    score += 20;
                }
                if (game.getThirdGenre() != null && 
                    game.getThirdGenre().toLowerCase().contains(genre.toLowerCase())) {
                    score += 15;
                }
            }
        }
        
        // Platform matching
        if (platforms != null && !platforms.isEmpty() && game.getPlatforms() != null) {
            for (String platform : platforms) {
                if (game.getPlatforms().toLowerCase().contains(platform.toLowerCase())) {
                    score += 10;
                }
            }
        }
        
        // Rating bonus
        if (game.getRating() != null) {
            if (minRating != null && game.getRating() < minRating) {
                return 0; // Filter out
            }
            score += game.getRating() / 5.0;
        }
        
        return score;
    }
}
