package com.gamerecommender.controller;

import com.gamerecommender.entity.Game;
import com.gamerecommender.service.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/games")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173", "*"})
public class GameController {
    
    @Autowired
    private GameService gameService;
    
    // ==================== GET ENDPOINTS ====================
    
    /**
     * GET /api/games - Get all games
     */
    @GetMapping
    public ResponseEntity<List<Game>> getAllGames() {
        return ResponseEntity.ok(gameService.getAllGames());
    }
    
    /**
     * GET /api/games/{id} - Get game by ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<Game> getGameById(@PathVariable Integer id) {
        return gameService.getGameById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
    
    /**
     * GET /api/games/search?q=query - Search games
     */
    @GetMapping("/search")
    public ResponseEntity<List<Game>> searchGames(@RequestParam String q) {
        return ResponseEntity.ok(gameService.searchGames(q));
    }
    
    /**
     * GET /api/games/genre/{genre} - Get games by genre
     */
    @GetMapping("/genre/{genre}")
    public ResponseEntity<List<Game>> getGamesByGenre(@PathVariable String genre) {
        return ResponseEntity.ok(gameService.getGamesByGenre(genre));
    }
    
    /**
     * GET /api/games/platform/{platform} - Get games by platform
     */
    @GetMapping("/platform/{platform}")
    public ResponseEntity<List<Game>> getGamesByPlatform(@PathVariable String platform) {
        return ResponseEntity.ok(gameService.getGamesByPlatform(platform));
    }
    
    /**
     * GET /api/games/genres - Get all unique genres
     */
    @GetMapping("/genres")
    public ResponseEntity<List<String>> getAllGenres() {
        return ResponseEntity.ok(gameService.getAllGenres());
    }
    
    /**
     * GET /api/games/count - Get total count
     */
    @GetMapping("/count")
    public ResponseEntity<Map<String, Long>> getCount() {
        return ResponseEntity.ok(Map.of("count", gameService.getCount()));
    }
    
    // ==================== RECOMMENDATION ENDPOINTS ====================
    
    /**
     * GET /api/games/recommend/{id} - Get recommendations based on a game
     */
    @GetMapping("/recommend/{id}")
    public ResponseEntity<List<Game>> getRecommendations(
            @PathVariable Integer id,
            @RequestParam(defaultValue = "5") int limit) {
        return ResponseEntity.ok(gameService.getRecommendations(id, limit));
    }
    
    /**
     * GET /api/games/recommend - Get recommendations based on preferences
     * Example: /api/games/recommend?genres=Action,RPG&platforms=Steam&minRating=80
     */
    @GetMapping("/recommend")
    public ResponseEntity<List<Game>> getRecommendationsByPreferences(
            @RequestParam(required = false) List<String> genres,
            @RequestParam(required = false) List<String> platforms,
            @RequestParam(required = false) Integer minRating,
            @RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(
            gameService.getRecommendationsByPreferences(genres, platforms, minRating, limit)
        );
    }
    
    // ==================== CREATE/UPDATE/DELETE ENDPOINTS ====================
    
    /**
     * POST /api/games - Create a new game
     */
    @PostMapping
    public ResponseEntity<Game> createGame(@RequestBody Game game) {
        Game created = gameService.createGame(game);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }
    
    /**
     * PUT /api/games/{id} - Update a game
     */
    @PutMapping("/{id}")
    public ResponseEntity<Game> updateGame(@PathVariable Integer id, @RequestBody Game game) {
        return gameService.updateGame(id, game)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
    
    /**
     * DELETE /api/games/{id} - Delete a game
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGame(@PathVariable Integer id) {
        if (gameService.deleteGame(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
    
    // ==================== HEALTH CHECK ====================
    
    /**
     * GET /api/games/health - Health check
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> healthCheck() {
        return ResponseEntity.ok(Map.of(
            "status", "UP",
            "service", "Game Recommender API",
            "gamesCount", gameService.getCount()
        ));
    }
}
