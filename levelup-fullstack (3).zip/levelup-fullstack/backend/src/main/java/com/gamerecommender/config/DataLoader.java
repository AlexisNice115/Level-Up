package com.gamerecommender.config;

import com.gamerecommender.entity.Game;
import com.gamerecommender.repository.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

/**
 * Loads sample game data on startup if the database is empty.
 */
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private GameRepository gameRepository;

    @Override
    public void run(String... args) {
        if (gameRepository.count() == 0) {
            System.out.println("Loading game database...");
            gameRepository.saveAll(getGames());
            System.out.println("Loaded " + gameRepository.count() + " games!");
        } else {
            System.out.println("Database already contains " + gameRepository.count() + " games.");
        }
    }

    private List<Game> getGames() {
        return Arrays.asList(
            new Game(1, "The Last of Us", 2013, "Action-Adventure", "Survival", "Post-Apocalyptic", 95, "PlayStation Store / Steam"),
            new Game(2, "Ghost of Tsushima", 2020, "Action-Adventure", "Open-World/Sandbox", "Stealth", 87, "PlayStation Store / Steam"),
            new Game(3, "Detroit: Become Human", 2018, "Adventure", "Interactive Movie", "Plot with Many Endings", 78, "PlayStation Store / Steam"),
            new Game(4, "Counter-Strike 2", 2023, "Shooter", "Tactical", "Competitive", 80, "Steam"),
            new Game(5, "Call of Duty: Modern Warfare II", 2022, "Shooter", "First-Person", "Action", 76, "Steam / Epic Games Store"),
            new Game(6, "Overwatch 2", 2022, "Shooter", "Hero Shooter", "Multiplayer", 79, "Battle.net"),
            new Game(7, "Assassin's Creed Mirage", 2023, "Action-Adventure", "Stealth", "Open-World/Sandbox", 77, "Ubisoft Connect / Epic Games Store"),
            new Game(8, "Assassin's Creed Valhalla", 2020, "Action-Adventure", "Open-World/Sandbox", "RPG", 80, "Ubisoft Connect / Epic Games Store"),
            new Game(9, "Assassin's Creed Origins", 2017, "Action-Adventure", "RPG", "Open-World/Sandbox", 84, "Steam / Ubisoft Connect"),
            new Game(10, "Red Dead Redemption 2", 2018, "Action-Adventure", "Open-World/Sandbox", "Western", 96, "Steam / Rockstar Games Launcher"),
            new Game(11, "Grand Theft Auto V", 2013, "Open-World/Sandbox", "Action-Adventure", "Crime", 97, "Steam / Rockstar Games Launcher"),
            new Game(12, "Elden Ring", 2022, "RPG", "Soulsborne", "Open-World/Sandbox", 96, "Steam"),
            new Game(13, "Dark Souls III", 2016, "RPG", "Soulsborne", "Action", 89, "Steam"),
            new Game(14, "Sekiro: Shadows Die Twice", 2019, "Action-Adventure", "Soulsborne", "Singleplayer", 90, "Steam"),
            new Game(15, "Hades", 2018, "Roguelike", "Action", "Indie", 93, "Steam / Epic Games Store"),
            new Game(16, "Honkai: Star Rail", 2023, "RPG", "Turn-Based", "Gacha", 82, "Epic Games Store"),
            new Game(17, "Genshin Impact", 2020, "RPG", "Open-World/Sandbox", "Gacha", 86, "Epic Games Store"),
            new Game(18, "Valorant", 2020, "Shooter", "Tactical", "Competitive", 80, "Riot Client"),
            new Game(19, "League of Legends", 2009, "MOBA", "Competitive", "Team-Based", 78, "Riot Client"),
            new Game(20, "Dota 2", 2013, "MOBA", "Competitive", "Team-Based", 90, "Steam"),
            new Game(21, "Apex Legends", 2019, "Shooter", "Battle Royale", "Hero Shooter", 88, "Steam / EA App"),
            new Game(22, "Fortnite", 2017, "Shooter", "Battle Royale", "Building", 85, "Epic Games Store"),
            new Game(23, "Minecraft", 2011, "Sandbox", "Survival", "Creative", 93, "Minecraft Launcher"),
            new Game(24, "Stardew Valley", 2016, "Simulation", "Farming", "Indie", 89, "Steam / GOG"),
            new Game(25, "The Witcher 3: Wild Hunt", 2015, "RPG", "Open-World/Sandbox", "Fantasy", 93, "Steam / GOG"),
            new Game(26, "Cyberpunk 2077", 2020, "RPG", "Open-World/Sandbox", "Sci-Fi", 86, "Steam / GOG / Epic Games Store"),
            new Game(27, "Horizon Zero Dawn", 2017, "Action-Adventure", "Open-World/Sandbox", "Sci-Fi", 89, "Steam / Epic Games Store"),
            new Game(28, "Horizon Forbidden West", 2022, "Action-Adventure", "Open-World/Sandbox", "Sci-Fi", 88, "PlayStation Store"),
            new Game(29, "Forza Horizon 5", 2021, "Racing", "Open-World/Sandbox", "Simulation", 92, "Steam / Microsoft Store"),
            new Game(30, "Gran Turismo 7", 2022, "Racing", "Simulation", "Sports", 87, "PlayStation Store"),
            new Game(31, "FIFA 23", 2022, "Sports", "Football/Soccer", "Multiplayer", 79, "Steam / EA App"),
            new Game(32, "NBA 2K24", 2023, "Sports", "Basketball", "Multiplayer", 72, "Steam"),
            new Game(33, "Madden NFL 24", 2023, "Sports", "American Football", "Simulation", 68, "Steam / EA App"),
            new Game(34, "The Sims 4", 2014, "Simulation", "Life Simulation", "Creative", 70, "Steam / EA App"),
            new Game(35, "Cities: Skylines", 2015, "Simulation", "City Builder", "Strategy", 85, "Steam"),
            new Game(36, "Civilization VI", 2016, "Strategy", "Turn-Based", "4X", 88, "Steam / Epic Games Store"),
            new Game(37, "Total War: Warhammer III", 2022, "Strategy", "RTS", "Turn-Based", 86, "Steam / Epic Games Store"),
            new Game(38, "Starcraft II", 2010, "RTS", "Sci-Fi", "Competitive", 93, "Battle.net"),
            new Game(39, "World of Warcraft", 2004, "MMORPG", "Fantasy", "Online", 89, "Battle.net"),
            new Game(40, "Final Fantasy XIV", 2013, "MMORPG", "Fantasy", "Online", 89, "Steam / Square Enix Launcher"),
            new Game(41, "Path of Exile", 2013, "RPG", "Action", "Online", 86, "Steam"),
            new Game(42, "Diablo IV", 2023, "RPG", "Action", "Online", 85, "Battle.net"),
            new Game(43, "Lost Ark", 2019, "MMORPG", "Action", "Online", 81, "Steam"),
            new Game(44, "Terraria", 2011, "Sandbox", "Adventure", "Survival", 91, "Steam"),
            new Game(45, "Don't Starve Together", 2016, "Survival", "Co-op", "Indie", 82, "Steam"),
            new Game(46, "Rust", 2018, "Survival", "Multiplayer", "Sandbox", 76, "Steam"),
            new Game(47, "ARK: Survival Evolved", 2017, "Survival", "Open-World/Sandbox", "Dinosaur", 70, "Steam / Epic Games Store"),
            new Game(48, "Subnautica", 2018, "Survival", "Adventure", "Underwater", 87, "Steam / Epic Games Store"),
            new Game(49, "No Man's Sky", 2016, "Adventure", "Exploration", "Sci-Fi", 78, "Steam"),
            new Game(50, "Factorio", 2020, "Simulation", "Automation", "Strategy", 91, "Steam"),
            new Game(51, "Satisfactory", 2020, "Simulation", "Automation", "First-Person", 85, "Steam / Epic Games Store"),
            new Game(52, "RimWorld", 2018, "Simulation", "Colony Sim", "Strategy", 87, "Steam"),
            new Game(53, "Crusader Kings III", 2020, "Strategy", "Grand Strategy", "Simulation", 91, "Steam"),
            new Game(54, "Europa Universalis IV", 2013, "Strategy", "Grand Strategy", "Historical", 87, "Steam"),
            new Game(55, "Hearts of Iron IV", 2016, "Strategy", "Grand Strategy", "War", 83, "Steam"),
            new Game(56, "Planet Zoo", 2019, "Simulation", "Management", "Building", 81, "Steam"),
            new Game(57, "Planet Coaster", 2016, "Simulation", "Management", "Building", 84, "Steam"),
            new Game(58, "RollerCoaster Tycoon Classic", 2016, "Simulation", "Management", "Building", 85, "Steam / Mobile"),
            new Game(59, "Age of Empires IV", 2021, "RTS", "Historical", "Strategy", 81, "Steam / Microsoft Store"),
            new Game(60, "Age of Empires II: Definitive Edition", 2019, "RTS", "Historical", "Strategy", 90, "Steam / Microsoft Store"),
            new Game(61, "Halo Infinite", 2021, "Shooter", "Sci-Fi", "Multiplayer", 80, "Steam / Microsoft Store"),
            new Game(62, "DOOM Eternal", 2020, "Shooter", "Action", "Singleplayer", 90, "Steam"),
            new Game(63, "Far Cry 6", 2021, "Shooter", "Open-World/Sandbox", "Action", 75, "Ubisoft Connect / Epic Games Store"),
            new Game(64, "Borderlands 3", 2019, "Shooter", "Looter Shooter", "Co-op", 81, "Steam / Epic Games Store"),
            new Game(65, "Destiny 2", 2017, "Shooter", "Looter Shooter", "Online", 83, "Steam"),
            new Game(66, "Rainbow Six Siege", 2015, "Shooter", "Tactical", "Competitive", 82, "Steam / Ubisoft Connect"),
            new Game(67, "Warframe", 2013, "Shooter", "Looter Shooter", "Online", 78, "Steam"),
            new Game(68, "Monster Hunter: World", 2018, "RPG", "Action", "Co-op", 90, "Steam"),
            new Game(69, "Monster Hunter Rise", 2021, "RPG", "Action", "Co-op", 88, "Steam"),
            new Game(70, "Pokémon Legends: Arceus", 2022, "RPG", "Adventure", "Creature Collection", 83, "Nintendo Switch"),
            new Game(71, "Pokémon Scarlet/Violet", 2022, "RPG", "Adventure", "Creature Collection", 72, "Nintendo Switch"),
            new Game(72, "Super Mario Odyssey", 2017, "Platformer", "Adventure", "3D Platformer", 97, "Nintendo Switch"),
            new Game(73, "The Legend of Zelda: Breath of the Wild", 2017, "Action-Adventure", "Open-World/Sandbox", "Fantasy", 97, "Nintendo Switch"),
            new Game(74, "The Legend of Zelda: Tears of the Kingdom", 2023, "Action-Adventure", "Open-World/Sandbox", "Fantasy", 96, "Nintendo Switch"),
            new Game(75, "Celeste", 2018, "Platformer", "Indie", "Precision Platformer", 94, "Steam / Nintendo Switch"),
            new Game(76, "Hollow Knight", 2017, "Metroidvania", "Indie", "Action", 90, "Steam / Nintendo Switch"),
            new Game(77, "Ori and the Blind Forest", 2015, "Platformer", "Metroidvania", "Indie", 88, "Steam / Microsoft Store"),
            new Game(78, "Ori and the Will of the Wisps", 2020, "Platformer", "Metroidvania", "Indie", 90, "Steam / Microsoft Store"),
            new Game(79, "Cuphead", 2017, "Platformer", "Run and Gun", "Indie", 88, "Steam / GOG"),
            new Game(80, "Dead Cells", 2018, "Roguelike", "Metroidvania", "Action", 89, "Steam / Nintendo Switch"),
            new Game(81, "Slay the Spire", 2019, "Roguelike", "Deckbuilder", "Indie", 89, "Steam / Nintendo Switch"),
            new Game(82, "Inscryption", 2021, "Card Game", "Puzzle", "Horror", 85, "Steam"),
            new Game(83, "Return of the Obra Dinn", 2018, "Puzzle", "Mystery", "Indie", 89, "Steam"),
            new Game(84, "Outer Wilds", 2019, "Adventure", "Exploration", "Sci-Fi", 92, "Steam / Epic Games Store"),
            new Game(85, "Disco Elysium", 2019, "RPG", "Narrative", "Isometric", 95, "Steam / GOG"),
            new Game(86, "Baldur's Gate 3", 2023, "RPG", "Turn-Based", "Fantasy", 96, "Steam / GOG"),
            new Game(87, "Lies of P", 2023, "RPG", "Soulsborne", "Action", 83, "Steam"),
            new Game(88, "Wo Long: Fallen Dynasty", 2023, "RPG", "Soulsborne", "Action", 78, "Steam"),
            new Game(89, "Remnant II", 2023, "Shooter", "Soulsborne", "Co-op", 80, "Steam"),
            new Game(90, "The Division 2", 2019, "Shooter", "Looter Shooter", "Co-op", 82, "Steam / Ubisoft Connect"),
            new Game(91, "Alan Wake 2", 2023, "Horror", "Adventure", "Narrative", 89, "Epic Games Store"),
            new Game(92, "Resident Evil 4 Remake", 2023, "Horror", "Action", "Survival", 93, "Steam"),
            new Game(93, "Resident Evil Village", 2021, "Horror", "Action", "Survival", 84, "Steam"),
            new Game(94, "Dead Space Remake", 2023, "Horror", "Action", "Sci-Fi", 89, "Steam / EA App"),
            new Game(95, "Silent Hill 2 Remake", 2024, "Horror", "Psychological", "Story-Driven", 82, "Steam / PlayStation Store"),
            new Game(96, "HITMAN World of Assassination", 2022, "Stealth", "Action", "Sandbox", 88, "Steam / Epic Games Store"),
            new Game(97, "Metal Gear Solid V: The Phantom Pain", 2015, "Stealth", "Action-Adventure", "Open-World/Sandbox", 91, "Steam"),
            new Game(98, "Dishonored 2", 2016, "Stealth", "Action-Adventure", "Immersive Sim", 88, "Steam"),
            new Game(99, "Prey (2017)", 2017, "Shooter", "Immersive Sim", "Sci-Fi", 84, "Steam"),
            new Game(100, "Black Myth: Wukong", 2024, "Action-Adventure", "Soulsborne", "Fantasy", 88, "Steam / Epic Games Store"),
            new Game(101, "Clash Royale", 2016, "Strategy", "Card Game", "Real-Time", 85, "Google Play / App Store"),
            new Game(102, "Clash of Clans", 2012, "Strategy", "Base Builder", "Multiplayer", 83, "Google Play / App Store"),
            new Game(103, "Brawl Stars", 2018, "Shooter", "MOBA", "Arcade", 82, "Google Play / App Store"),
            new Game(104, "PUBG Mobile", 2018, "Shooter", "Battle Royale", "Mobile", 78, "Google Play / App Store"),
            new Game(105, "Call of Duty: Mobile", 2019, "Shooter", "Action", "Mobile", 81, "Google Play / App Store"),
            new Game(106, "Mobile Legends: Bang Bang", 2016, "MOBA", "Action", "Multiplayer", 80, "Google Play / App Store"),
            new Game(107, "League of Legends: Wild Rift", 2020, "MOBA", "Action", "Mobile", 83, "Google Play / App Store"),
            new Game(108, "Among Us", 2018, "Party", "Social Deduction", "Multiplayer", 80, "Steam / Google Play / App Store"),
            new Game(109, "Candy Crush Saga", 2012, "Puzzle", "Match-3", "Casual", 75, "Google Play / App Store"),
            new Game(110, "Subway Surfers", 2012, "Arcade", "Endless Runner", "Casual", 78, "Google Play / App Store"),
            new Game(111, "Temple Run 2", 2013, "Arcade", "Endless Runner", "Casual", 76, "Google Play / App Store"),
            new Game(112, "8 Ball Pool", 2010, "Sports", "Billiards", "Casual", 80, "Google Play / App Store"),
            new Game(113, "FIFA Mobile", 2016, "Sports", "Football/Soccer", "Mobile", 73, "Google Play / App Store"),
            new Game(114, "Asphalt 9: Legends", 2018, "Racing", "Arcade", "Mobile", 81, "Google Play / App Store"),
            new Game(115, "Genshin Impact (Mobile)", 2020, "RPG", "Open-World/Sandbox", "Gacha", 86, "Google Play / App Store"),
            new Game(116, "Honkai: Star Rail (Mobile)", 2023, "RPG", "Turn-Based", "Gacha", 82, "Google Play / App Store"),
            new Game(117, "Royal Match", 2021, "Puzzle", "Match-3", "Casual", 78, "Google Play / App Store"),
            new Game(118, "Roblox", 2006, "Sandbox", "User-Generated", "Online", 80, "Google Play / App Store / PC"),
            new Game(119, "Hay Day", 2012, "Simulation", "Farming", "Casual Farming", 80, "Google Play / App Store")
        );
    }
}
