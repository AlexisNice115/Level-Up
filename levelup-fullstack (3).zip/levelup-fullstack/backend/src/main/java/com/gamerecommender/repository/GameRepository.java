package com.gamerecommender.repository;

import com.gamerecommender.entity.Game;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface GameRepository extends MongoRepository<Game, String> {
    
    Optional<Game> findByGameId(Integer gameId);
    
    List<Game> findByTitleContainingIgnoreCase(String title);
    
    List<Game> findByPrimaryGenreIgnoreCase(String genre);
    
    @Query("{ $or: [ " +
           "{ 'primaryGenre': { $regex: ?0, $options: 'i' } }, " +
           "{ 'secondaryGenres': { $regex: ?0, $options: 'i' } }, " +
           "{ 'thirdGenre': { $regex: ?0, $options: 'i' } } " +
           "] }")
    List<Game> findByAnyGenre(String genre);
    
    List<Game> findByPlatformsContainingIgnoreCase(String platform);
    
    List<Game> findByRatingGreaterThanEqual(Integer rating);
    
    List<Game> findByYear(Integer year);
    
    @Query("{ $or: [ " +
           "{ 'title': { $regex: ?0, $options: 'i' } }, " +
           "{ 'primaryGenre': { $regex: ?0, $options: 'i' } }, " +
           "{ 'secondaryGenres': { $regex: ?0, $options: 'i' } }, " +
           "{ 'thirdGenre': { $regex: ?0, $options: 'i' } } " +
           "] }")
    List<Game> searchGames(String query);
}
