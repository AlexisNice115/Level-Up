package com.gamerecommender.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.index.Indexed;

/**
 * Game entity - matches the React frontend format exactly.
 */
@Document(collection = "games")
public class Game {
    
    @Id
    private String id;
    
    @Indexed(unique = true)
    private Integer gameId;
    
    @Indexed
    private String title;
    
    private Integer year;
    
    private String primaryGenre;
    
    private String secondaryGenres;
    
    private String thirdGenre;
    
    private Integer rating;  // 0-100 scale
    
    private String platforms;
    
    // Constructors
    public Game() {}
    
    public Game(Integer gameId, String title, Integer year, String primaryGenre, 
                String secondaryGenres, String thirdGenre, Integer rating, String platforms) {
        this.gameId = gameId;
        this.title = title;
        this.year = year;
        this.primaryGenre = primaryGenre;
        this.secondaryGenres = secondaryGenres;
        this.thirdGenre = thirdGenre;
        this.rating = rating;
        this.platforms = platforms;
    }
    
    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public Integer getGameId() { return gameId; }
    public void setGameId(Integer gameId) { this.gameId = gameId; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public Integer getYear() { return year; }
    public void setYear(Integer year) { this.year = year; }
    
    public String getPrimaryGenre() { return primaryGenre; }
    public void setPrimaryGenre(String primaryGenre) { this.primaryGenre = primaryGenre; }
    
    public String getSecondaryGenres() { return secondaryGenres; }
    public void setSecondaryGenres(String secondaryGenres) { this.secondaryGenres = secondaryGenres; }
    
    public String getThirdGenre() { return thirdGenre; }
    public void setThirdGenre(String thirdGenre) { this.thirdGenre = thirdGenre; }
    
    public Integer getRating() { return rating; }
    public void setRating(Integer rating) { this.rating = rating; }
    
    public String getPlatforms() { return platforms; }
    public void setPlatforms(String platforms) { this.platforms = platforms; }
}
